import React, { useState, useEffect } from 'react';
import {
  Container, Grid, Paper, Box, Typography, useMediaQuery, useTheme,
  Button, Alert
} from '@mui/material';
import { useLocation, useSearchParams, useNavigate } from 'react-router-dom';
import ConversationList from '../../components/messaging/ConversationList';
import MessageThread from '../../components/messaging/MessageThread';
import LoadingSpinner from '../../components/common/LoadingSpinner';
import messagingService from '../../services/messaging';
import contractService from '../../services/contracts';  // Add this import

const Messages = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const location = useLocation();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  
  const [conversations, setConversations] = useState([]);
  const [selectedConversation, setSelectedConversation] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [contracts, setContracts] = useState([]); // Add this
  
  const contractId = searchParams.get('contract_id');

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    if (contractId && !loading) {
      handleContractConversation(contractId);
    }
  }, [contractId, loading]);

  const fetchData = async () => {
    try {
      // Fetch both conversations and contracts
      const [convData, contractData] = await Promise.all([
        messagingService.getConversations(),
        contractService.getContracts()
      ]);
      
      console.log('Conversations:', convData);
      console.log('Contracts:', contractData);
      
      setConversations(convData.results || convData || []);
      setContracts(contractData.results || contractData || []);
    } catch (error) {
      console.error('Error fetching data:', error);
      setError('Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  const handleContractConversation = async (contractId) => {
    const existingConv = conversations.find(
      conv => conv.contract?.id === parseInt(contractId)
    );
    
    if (existingConv) {
      setSelectedConversation(existingConv);
    } else {
      try {
        console.log('Creating conversation for contract:', contractId);
        const conversation = await messagingService.getConversationByContract(contractId);
        setConversations([conversation, ...conversations]);
        setSelectedConversation(conversation);
      } catch (error) {
        console.error('Error creating conversation:', error);
        console.error('Error response:', error.response?.data);
        setError(error.response?.data?.error || 'Failed to create conversation');
      }
    }
  };

  const handleSelectConversation = (conversation) => {
    setSelectedConversation(conversation);
    if (conversation.unread_count > 0) {
      const updatedConversations = conversations.map(conv => 
        conv.id === conversation.id ? { ...conv, unread_count: 0 } : conv
      );
      setConversations(updatedConversations);
    }
  };

  const handleNewMessage = (message) => {
    const updatedConversations = conversations.map(conv => {
      if (conv.id === selectedConversation.id) {
        return {
          ...conv,
          last_message: message,
          updated_at: message.created_at
        };
      }
      return conv;
    });
    
    updatedConversations.sort((a, b) => 
      new Date(b.updated_at || b.created_at) - new Date(a.updated_at || a.created_at)
    );
    
    setConversations(updatedConversations);
  };

  // Debug function to create conversation
  const createTestConversation = async (contractId) => {
    try {
      console.log('Creating test conversation for contract:', contractId);
      const conversation = await messagingService.getConversationByContract(contractId);
      console.log('Created conversation:', conversation);
      await fetchData(); // Refresh all data
    } catch (error) {
      console.error('Test conversation error:', error);
      alert(`Error: ${error.response?.data?.error || error.message}`);
    }
  };

  if (loading) return <LoadingSpinner />;

  return (
    <Container maxWidth="lg">
      <Box sx={{ mt: 4, mb: 4 }}>
        <Typography variant="h4" gutterBottom>
          Messages
        </Typography>

        {error && (
          <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>
            {error}
          </Alert>
        )}

        {/* Debug section - Remove this after fixing */}
        <Box sx={{ mb: 2, p: 2, bgcolor: '#f5f5f5' }}>
          <Typography variant="h6">Debug Info:</Typography>
          <Typography>Total Conversations: {conversations.length}</Typography>
          <Typography>Total Contracts: {contracts.length}</Typography>
          <Typography>Active Contracts: {contracts.filter(c => c.status === 'ACTIVE' || c.status === 'Active').length}</Typography>
          
          {contracts.filter(c => c.status === 'ACTIVE' || c.status === 'Active').length > 0 && (
            <Box sx={{ mt: 1 }}>
              <Typography variant="subtitle2">Create conversation for contract:</Typography>
              {contracts.filter(c => c.status === 'ACTIVE' || c.status === 'Active').map(contract => (
                <Button 
                  key={contract.id}
                  size="small" 
                  variant="outlined" 
                  sx={{ mr: 1, mt: 1 }}
                  onClick={() => createTestConversation(contract.id)}
                >
                  Contract #{contract.id} - {contract.project?.title || 'No title'}
                </Button>
              ))}
            </Box>
          )}
        </Box>

        <Paper elevation={3} sx={{ height: '75vh', overflow: 'hidden' }}>
          <Grid container sx={{ height: '100%' }}>
            <Grid 
              item 
              xs={12} 
              md={4} 
              sx={{ 
                borderRight: { md: '1px solid #e0e0e0' },
                height: '100%',
                overflow: 'auto',
                display: { xs: selectedConversation && isMobile ? 'none' : 'block' }
              }}
            >
              {conversations.length === 0 ? (
                <Box sx={{ p: 3, textAlign: 'center' }}>
                  <Typography color="text.secondary" gutterBottom>
                    No conversations yet
                  </Typography>
                  <Typography variant="body2" color="text.secondary" paragraph>
                    Start a conversation from an active contract
                  </Typography>
                  <Button 
                    variant="contained"
                    onClick={() => navigate('/contracts')}
                  >
                    View Contracts
                  </Button>
                </Box>
              ) : (
                <ConversationList
                  conversations={conversations}
                  selectedConversation={selectedConversation}
                  onSelectConversation={handleSelectConversation}
                />
              )}
            </Grid>

            <Grid 
              item 
              xs={12} 
              md={8} 
              sx={{ 
                height: '100%',
                display: { xs: !selectedConversation && isMobile ? 'none' : 'block' }
              }}
            >
              <MessageThread
                conversation={selectedConversation}
                onNewMessage={handleNewMessage}
              />
            </Grid>
          </Grid>
        </Paper>
      </Box>
    </Container>
  );
};

export default Messages;