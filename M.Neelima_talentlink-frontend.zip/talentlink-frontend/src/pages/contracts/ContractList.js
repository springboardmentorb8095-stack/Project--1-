import React, { useState, useEffect } from 'react';
import {
  Container, Box, Typography, Grid, Paper, 
  Tabs, Tab, Button, Alert  
} from '@mui/material';
import { Add } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import ContractCard from '../../components/contracts/ContractCard';
import LoadingSpinner from '../../components/common/LoadingSpinner';
import contractService from '../../services/contracts';

const ContractList = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [contracts, setContracts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tabValue, setTabValue] = useState(0);

  useEffect(() => {
    fetchContracts();
  }, []);

  const fetchContracts = async () => {
    try {
      const data = await contractService.getContracts();
      setContracts(data.results || data);
    } catch (error) {
      console.error('Error fetching contracts:', error);
    } finally {
      setLoading(false);
    }
  };

  const filterContracts = (status) => {
    if (status === 'all') return contracts;
    return contracts.filter(c => 
      c.status === status || c.status === status.charAt(0).toUpperCase() + status.slice(1).toLowerCase()
    );
  };

  if (loading) return <LoadingSpinner />;

  const activeContracts = filterContracts('ACTIVE');
  const completedContracts = filterContracts('COMPLETED');
  const allContracts = contracts;

  return (
    <Container maxWidth="lg">
      <Box sx={{ mt: 4, mb: 4 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
          <Typography variant="h4">
            My Contracts
          </Typography>
        </Box>

        <Paper elevation={1} sx={{ mb: 3 }}>
          <Tabs 
            value={tabValue} 
            onChange={(e, newValue) => setTabValue(newValue)}
            variant="fullWidth"
          >
            <Tab label={`Active (${activeContracts.length})`} />
            <Tab label={`Completed (${completedContracts.length})`} />
            <Tab label={`All (${allContracts.length})`} />
          </Tabs>
        </Paper>

       <Grid container spacing={3}>
        {(tabValue === 0 ? activeContracts :
          tabValue === 1 ? completedContracts : allContracts
        ).map((contract) => (
          <Grid item xs={12} md={6} lg={4} key={contract.id}>
            <ContractCard contract={contract} />
            
            {/* Add review reminder for completed contracts */}
            {contract.status === 'COMPLETED' && !contract.has_review && (
              <Alert 
                severity="info" 
                sx={{ mt: 1 }}
                action={
                  <Button 
                    size="small" 
                    onClick={() => navigate(`/reviews/submit/${contract.id}`)}
                  >
                    Write Review
                  </Button>
                }
              >
                Don't forget to review this contract
              </Alert>
            )}
          </Grid>
        ))}
      </Grid>

        {(tabValue === 0 ? activeContracts :
          tabValue === 1 ? completedContracts : allContracts
        ).length === 0 && (
          <Box sx={{ textAlign: 'center', py: 8 }}>
            <Typography variant="h6" color="text.secondary">
              No contracts found
            </Typography>
          </Box>
        )}
      </Box>
    </Container>
  );
};

export default ContractList;