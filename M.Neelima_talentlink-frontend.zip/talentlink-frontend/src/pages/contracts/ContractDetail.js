import React, { useState, useEffect } from 'react';
import {
  Container, Box, Paper, Typography, Grid, Button, 
  Divider, Alert, Dialog, DialogTitle, DialogContent,
  DialogContentText, DialogActions, Card, CardContent
} from '@mui/material';
import {
  AccessTime, AttachMoney, Person, CalendarToday, 
  Description, CheckCircle, Cancel, Chat
} from '@mui/icons-material';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import ContractStatusBadge from '../../components/contracts/ContractStatusBadge';
import LoadingSpinner from '../../components/common/LoadingSpinner';
import contractService from '../../services/contracts';
import { formatCurrency, formatDate } from '../../services/utils';


import reviewService from '../../services/reviews';
import RatingStars from '../../components/reviews/RatingStars';

const ContractDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [contract, setContract] = useState(null);
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [completeDialogOpen, setCompleteDialogOpen] = useState(false);
  const [terminateDialogOpen, setTerminateDialogOpen] = useState(false);
  
  // Add these new state variables HERE (inside the component)
  const [reviews, setReviews] = useState([]);
  const [hasReviewed, setHasReviewed] = useState(false);
  useEffect(() => {
    fetchContractData();
  }, [id]);

 const fetchContractData = async () => {
  try {
    const [contractData, analyticsData] = await Promise.all([
      contractService.getContract(id),
      contractService.getContractAnalytics(id)
    ]);
    setContract(contractData);
    setAnalytics(analyticsData);

    // Check if user has already reviewed
    if (contractData.status === 'COMPLETED' || contractData.status === 'Completed') {
      try {
        const reviewsData = await reviewService.getReviews({ contract: id });
        const userReviews = reviewsData.results || reviewsData;
        setReviews(userReviews);
        
        const currentUser = JSON.parse(localStorage.getItem('user'));
        const userReview = userReviews.find(r => r.reviewer.id === currentUser.id);
        setHasReviewed(!!userReview);
      } catch (error) {
        console.error('Error fetching reviews:', error);
      }
    }
  } catch (error) {
    console.error('Error fetching contract:', error);
    setError('Failed to load contract details');
  } finally {
    setLoading(false);
  }
};

  const handleCompleteContract = async () => {
    try {
      await contractService.completeContract(id);
      setCompleteDialogOpen(false);
      // Refresh contract data
      fetchContractData();
      alert('Contract marked as completed successfully!');
    } catch (error) {
      console.error('Error completing contract:', error);
      alert('Failed to complete contract');
    }
  };

  const handleTerminateContract = async () => {
    try {
      await contractService.terminateContract(id);
      setTerminateDialogOpen(false);
      // Refresh contract data
      fetchContractData();
      alert('Contract terminated successfully!');
    } catch (error) {
      console.error('Error terminating contract:', error);
      alert('Failed to terminate contract');
    }
  };

  const handleStartConversation = () => {
    navigate(`/messages?contract_id=${id}`);
  };

  if (loading) return <LoadingSpinner />;
  if (error) return <Alert severity="error">{error}</Alert>;
  if (!contract) return <Alert severity="error">Contract not found</Alert>;

  const isClient = user.id === contract.client.id;
  const isFreelancer = user.id === contract.freelancer.id;
  const isActive = contract.status === 'ACTIVE' || contract.status === 'Active';

  return (
    <Container maxWidth="lg">
      <Box sx={{ mt: 4, mb: 4 }}>
        <Paper elevation={3} sx={{ p: 4 }}>
          {/* Header */}
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', mb: 3 }}>
            <Box>
              <Typography variant="h4" gutterBottom>
                {contract.project.title}
              </Typography>
              <ContractStatusBadge status={contract.status} size="large" />
            </Box>
            
            {isActive && (
              <Box sx={{ display: 'flex', gap: 2 }}>
                {isClient && (
                  <Button
                    variant="contained"
                    color="success"
                    startIcon={<CheckCircle />}
                    onClick={() => setCompleteDialogOpen(true)}
                  >
                    Mark Complete
                  </Button>
                )}
                <Button
                  variant="outlined"
                  color="error"
                  startIcon={<Cancel />}
                  onClick={() => setTerminateDialogOpen(true)}
                >
                  Terminate
                </Button>
              </Box>
            )}
          </Box>

          {/* Contract Info Grid */}
          <Grid container spacing={3} sx={{ mb: 4 }}>
            <Grid item xs={12} md={6}>
              <Card variant="outlined">
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    Contract Details
                  </Typography>
                  
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                    <AttachMoney sx={{ mr: 1, color: 'primary.main' }} />
                    <Box>
                      <Typography variant="body2" color="text.secondary">
                        Total Amount
                      </Typography>
                      <Typography variant="h6">
                        {formatCurrency(contract.total_amount)}
                      </Typography>
                    </Box>
                  </Box>

                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                    <CalendarToday sx={{ mr: 1, color: 'primary.main' }} />
                    <Box>
                      <Typography variant="body2" color="text.secondary">
                        Duration
                      </Typography>
                      <Typography variant="body1">
                        {formatDate(contract.start_date)} - {formatDate(contract.end_date)}
                      </Typography>
                    </Box>
                  </Box>

                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <AccessTime sx={{ mr: 1, color: 'primary.main' }} />
                    <Box>
                      <Typography variant="body2" color="text.secondary">
                        Created
                      </Typography>
                      <Typography variant="body1">
                        {formatDate(contract.created_at)}
                      </Typography>
                    </Box>
                  </Box>
                </CardContent>
              </Card>
            </Grid>

            <Grid item xs={12} md={6}>
              <Card variant="outlined">
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    Parties Involved
                  </Typography>
                  
                  <Box sx={{ mb: 3 }}>
                    <Typography variant="subtitle2" color="text.secondary">
                      Client
                    </Typography>
                    <Box sx={{ display: 'flex', alignItems: 'center', mt: 1 }}>
                      <Person sx={{ mr: 1 }} />
                      <Box>
                        <Typography variant="body1">
                          {contract.client.first_name} {contract.client.last_name}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          @{contract.client.username}
                        </Typography>
                      </Box>
                    </Box>
                  </Box>

                  <Box>
                    <Typography variant="subtitle2" color="text.secondary">
                      Freelancer
                    </Typography>
                    <Box sx={{ display: 'flex', alignItems: 'center', mt: 1 }}>
                      <Person sx={{ mr: 1 }} />
                      <Box>
                        <Typography variant="body1">
                          {contract.freelancer.first_name} {contract.freelancer.last_name}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          @{contract.freelancer.username}
                        </Typography>
                      </Box>
                    </Box>
                  </Box>
                </CardContent>
              </Card>
            </Grid>
          </Grid>

          {/* Analytics Section */}
          {analytics ? (
            <Card variant="outlined" sx={{ mb: 3 }}>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Contract Progress
                </Typography>
                
                <Grid container spacing={3}>
                  <Grid item xs={6} md={3}>
                    <Typography variant="body2" color="text.secondary">
                      Total Days
                    </Typography>
                    <Typography variant="h4">
                      {analytics.total_days}
                    </Typography>
                  </Grid>
                  
                  <Grid item xs={6} md={3}>
                    <Typography variant="body2" color="text.secondary">
                      Days Elapsed
                    </Typography>
                    <Typography variant="h4">
                      {analytics.elapsed_days}
                    </Typography>
                  </Grid>
                  
                  <Grid item xs={6} md={3}>
                    <Typography variant="body2" color="text.secondary">
                      Days Remaining
                    </Typography>
                    <Typography variant="h4" color={analytics.remaining_days < 0 ? 'error' : 'inherit'}>
                      {analytics.remaining_days}
                    </Typography>
                  </Grid>
                  
                  <Grid item xs={6} md={3}>
                    <Typography variant="body2" color="text.secondary">
                      Progress
                    </Typography>
                    <Typography variant="h4">
                      {analytics.progress_percentage}%
                    </Typography>
                  </Grid>
                </Grid>

                {analytics.message_count !== undefined && (
                  <Box sx={{ mt: 3 }}>
                    <Typography variant="body2" color="text.secondary" gutterBottom>
                      Messages Exchanged: {analytics.message_count}
                    </Typography>
                  </Box>
                )}
              </CardContent>
            </Card>
          ) : (
            <Alert severity="info" sx={{ mb: 3 }}>
              Contract analytics unavailable
            </Alert>
          )}
          {/* Terms Section */}
          <Card variant="outlined" sx={{ mb: 3 }}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Contract Terms
              </Typography>
              <Typography variant="body1" style={{ whiteSpace: 'pre-wrap' }}>
                {contract.terms}
              </Typography>
            </CardContent>
          </Card>

          {/* Original Proposal Info */}
          {contract.proposal && (
            <Card variant="outlined" sx={{ mb: 3 }}>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Original Proposal
                </Typography>
                
                <Box sx={{ mb: 2 }}>
                  <Typography variant="body2" color="text.secondary">
                    Proposed Rate
                  </Typography>
                  <Typography variant="body1">
                    {formatCurrency(contract.proposal.proposed_rate)}
                    {contract.project.budget_type === 'HOURLY' && '/hr'}
                  </Typography>
                </Box>

                <Box sx={{ mb: 2 }}>
                  <Typography variant="body2" color="text.secondary">
                    Estimated Duration
                  </Typography>
                  <Typography variant="body1">
                    {contract.proposal.estimated_duration} days
                  </Typography>
                </Box>

                <Box>
                  <Typography variant="body2" color="text.secondary">
                    Cover Letter
                  </Typography>
                  <Typography variant="body1" paragraph>
                    {contract.proposal.cover_letter}
                  </Typography>
                </Box>
              </CardContent>
            </Card>
          )}

          {/* Reviews Section */}
          {(contract.status === 'COMPLETED' || contract.status === 'Completed') && (
            <Card variant="outlined" sx={{ mb: 3 }}>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Reviews
                </Typography>
                
                {!hasReviewed && (
                  <Box sx={{ mb: 2 }}>
                    <Alert severity="info" action={
                      <Button 
                        color="inherit" 
                        size="small"
                        onClick={() => navigate(`/reviews/submit/${contract.id}`)}
                      >
                        Write Review
                      </Button>
                    }>
                      You haven't reviewed this contract yet.
                    </Alert>
                  </Box>
                )}

                {reviews.length > 0 ? (
                  reviews.map((review) => (
                    <Box key={review.id} sx={{ mb: 2, p: 2, bgcolor: 'grey.50', borderRadius: 1 }}>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                        <Typography variant="subtitle2">
                          {review.reviewer.first_name} {review.reviewer.last_name}
                          {review.reviewer.id === contract.client.id ? ' (Client)' : ' (Freelancer)'}
                        </Typography>
                        <RatingStars value={review.rating} readOnly size="small" />
                      </Box>
                      <Typography variant="body2">
                        {review.comment}
                      </Typography>
                    </Box>
                  ))
                ) : (
                  hasReviewed && (
                    <Typography color="text.secondary">
                      Reviews will appear here once both parties have submitted their reviews.
                    </Typography>
                  )
                )}
              </CardContent>
            </Card>
          )}
          {/* Action Buttons */}
          <Box sx={{ display: 'flex', gap: 2, mt: 3 }}>
            <Button
              variant="contained"
              startIcon={<Chat />}
              onClick={handleStartConversation}
            >
              Messages
            </Button>
            
            <Button
              variant="outlined"
              onClick={() => navigate('/contracts')}
            >
              Back to Contracts
            </Button>
          </Box>
        </Paper>
      </Box>

      {/* Complete Contract Dialog */}
      <Dialog
        open={completeDialogOpen}
        onClose={() => setCompleteDialogOpen(false)}
      >
        <DialogTitle>Complete Contract</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Are you sure you want to mark this contract as completed? 
            This will allow both parties to leave reviews and release payment.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setCompleteDialogOpen(false)}>Cancel</Button>
          <Button onClick={handleCompleteContract} variant="contained" color="success">
            Complete Contract
          </Button>
        </DialogActions>
      </Dialog>

      {/* Terminate Contract Dialog */}
      <Dialog
        open={terminateDialogOpen}
        onClose={() => setTerminateDialogOpen(false)}
      >
        <DialogTitle>Terminate Contract</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Are you sure you want to terminate this contract? 
            This action cannot be undone and may require dispute resolution.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setTerminateDialogOpen(false)}>Cancel</Button>
          <Button onClick={handleTerminateContract} variant="contained" color="error">
            Terminate Contract
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};

export default ContractDetail;