import React from 'react';
import { Container, Box } from '@mui/material';
import EditProjectForm from '../../components/projects/EditProjectForm';

const EditProject = () => {
  return (
    <Container maxWidth="md">
      <Box sx={{ mt: 4, mb: 4 }}>
        <EditProjectForm />
      </Box>
    </Container>
  );
};

export default EditProject;