import React, { useState, useEffect } from 'react';
import {
  Container, Box, Typography, Button, Grid, Paper,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  Chip, IconButton
} from '@mui/material';
import { Add, Edit, Visibility, Delete } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import LoadingSpinner from '../../components/common/LoadingSpinner';
import ErrorMessage from '../../components/common/ErrorMessage';
import projectService from '../../services/projects';
import { formatCurrency, formatDate } from '../../services/utils';

const MyProjects = () => {
  const navigate = useNavigate();
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchMyProjects();
  }, []);

  const fetchMyProjects = async () => {
    try {
      const data = await projectService.getMyProjects();
      setProjects(data);
    } catch (err) {
      setError('Failed to load your projects');
      console.error('Error fetching projects:', err);
    } finally {
      setLoading(false);
    }
  };

  // Add delete handler
const handleDeleteProject = async (projectId) => {
  if (window.confirm('Are you sure you want to delete this project?')) {
    try {
      await projectService.deleteProject(projectId);
      // Refresh the list
      fetchMyProjects();
    } catch (error) {
      console.error('Error deleting project:', error);
      alert('Failed to delete project');
    }
  }
};

  const getStatusColor = (status) => {
    const colors = {
      'OPEN': 'success',
      'IN_PROGRESS': 'warning',
      'COMPLETED': 'default',
      'CANCELLED': 'error'
    };
    return colors[status] || 'default';
  };

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorMessage error={error} />;

  return (
    <Container maxWidth="lg">
      <Box sx={{ mt: 4, mb: 4 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
          <Typography variant="h4">
            My Projects
          </Typography>
          
          <Button
            variant="contained"
            startIcon={<Add />}
            onClick={() => navigate('/projects/create')}
          >
            Create New Project
          </Button>
        </Box>

        {projects.length === 0 ? (
          <Paper sx={{ p: 4, textAlign: 'center' }}>
            <Typography variant="h6" color="text.secondary" gutterBottom>
              You haven't created any projects yet
            </Typography>
            <Button 
              variant="contained" 
              onClick={() => navigate('/projects/create')}
              sx={{ mt: 2 }}
            >
              Create Your First Project
            </Button>
          </Paper>
        ) : (
          <TableContainer component={Paper}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Title</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell>Budget</TableCell>
                  <TableCell>Proposals</TableCell>
                  <TableCell>Created</TableCell>
                  <TableCell>Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {projects.map((project) => (
                  <TableRow key={project.id}>
                    <TableCell>{project.title}</TableCell>
                    <TableCell>
                      <Chip 
                        label={project.status} 
                        color={getStatusColor(project.status)}
                        size="small"
                      />
                    </TableCell>
                    <TableCell>
                      {project.budget_type === 'FIXED' ? 
                        formatCurrency(project.budget_amount) : 
                        `${formatCurrency(project.budget_amount)}/hr`
                      }
                    </TableCell>
                    <TableCell>{project.proposals_count || 0}</TableCell>
                    <TableCell>{formatDate(project.created_at)}</TableCell>
                    // In the Actions cell of the table:
                    <TableCell>
                      <IconButton 
                        size="small" 
                        onClick={() => navigate(`/projects/${project.id}`)}
                        title="View"
                      >
                        <Visibility />
                      </IconButton>
                      {project.status === 'OPEN' && (
                        <>
                          <IconButton 
                            size="small" 
                            onClick={() => navigate(`/projects/${project.id}/edit`)}
                            title="Edit"
                            color="primary"
                          >
                            <Edit />
                          </IconButton>
                          <IconButton 
                            size="small" 
                            onClick={() => handleDeleteProject(project.id)}
                            title="Delete"
                            color="error"
                          >
                            <Delete />
                          </IconButton>
                        </>
                      )}
                    </TableCell>


                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        )}
      </Box>
    </Container>
  );
};

export default MyProjects;