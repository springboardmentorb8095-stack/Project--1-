import React from 'react';
import { Container, Box } from '@mui/material';
import CreateProjectForm from '../../components/projects/CreateProjectForm';

const CreateProject = () => {
  return (
    <Container maxWidth="md">
      <Box sx={{ mt: 4, mb: 4 }}>
        <CreateProjectForm />
      </Box>
    </Container>
  );
};

export default CreateProject;