import React, { useState, useEffect } from 'react';
import {
  Container, Grid, Box, Typography, Button, Pagination
} from '@mui/material';
import { Add } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import ProjectCard from '../../components/projects/ProjectCard';
import ProjectFilter from '../../components/projects/ProjectFilter';
import LoadingSpinner from '../../components/common/LoadingSpinner';
import ErrorMessage from '../../components/common/ErrorMessage';
import projectService from '../../services/projects';

const ProjectList = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [filters, setFilters] = useState({
    search: '',
    skills: '',
    budget_type: '',
    status: '',
    min_budget: '',
    max_budget: ''
  });

  useEffect(() => {
    fetchProjects();
  }, [page]);

  const fetchProjects = async () => {
    setLoading(true);
    setError('');
    
    try {
      const params = {
        page,
        ...filters
      };
      
      const response = await projectService.getProjects(params);
      setProjects(response.results || response);
      setTotalPages(Math.ceil(response.count / 20) || 1);
    } catch (err) {
      setError('Failed to load projects');
      console.error('Error fetching projects:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleApplyFilters = () => {
    setPage(1);
    fetchProjects();
  };

  const handleClearFilters = () => {
    setFilters({
      search: '',
      skills: '',
      budget_type: '',
      status: '',
      min_budget: '',
      max_budget: ''
    });
    setPage(1);
    fetchProjects();
  };

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorMessage error={error} />;

  return (
    <Container maxWidth="lg">
      <Box sx={{ mt: 4, mb: 4 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
          <Typography variant="h4">
            Projects
          </Typography>
          
          {user?.user_type === 'CLIENT' && (
            <Button
              variant="contained"
              startIcon={<Add />}
              onClick={() => navigate('/projects/create')}
            >
              Create Project
            </Button>
          )}
        </Box>

        <Grid container spacing={3}>
          <Grid item xs={12} md={3}>
            <ProjectFilter
              filters={filters}
              onFilterChange={setFilters}
              onApplyFilters={handleApplyFilters}
              onClearFilters={handleClearFilters}
            />
          </Grid>

          <Grid item xs={12} md={9}>
            {projects.length === 0 ? (
              <Box sx={{ textAlign: 'center', py: 8 }}>
                <Typography variant="h6" color="text.secondary">
                  No projects found
                </Typography>
              </Box>
            ) : (
              <>
                <Grid container spacing={3}>
                  {projects.map((project) => (
                    <Grid item xs={12} sm={6} key={project.id}>
                      <ProjectCard project={project} />
                    </Grid>
                  ))}
                </Grid>

                {totalPages > 1 && (
                  <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
                    <Pagination
                      count={totalPages}
                      page={page}
                      onChange={(e, value) => setPage(value)}
                      color="primary"
                    />
                  </Box>
                )}
              </>
            )}
          </Grid>
        </Grid>
      </Box>
    </Container>
  );
};

export default ProjectList;