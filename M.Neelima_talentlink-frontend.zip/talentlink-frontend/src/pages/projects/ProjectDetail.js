import React, { useState, useEffect } from 'react';
import {
  Container, Box, Typography, Button, Paper, Chip, Grid, Divider
} from '@mui/material';
import {
  AccessTime, AttachMoney, Work, CalendarToday, Person
} from '@mui/icons-material';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import LoadingSpinner from '../../components/common/LoadingSpinner';
import ErrorMessage from '../../components/common/ErrorMessage';
import projectService from '../../services/projects';
import { formatCurrency, formatDate } from '../../services/utils';


// In the imports, add:
import { useLocation } from 'react-router-dom';


const ProjectDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [project, setProject] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchProject();
  }, [id]);

  

  const fetchProject = async () => {
    try {
      const data = await projectService.getProject(id);
      setProject(data);
    } catch (err) {
      setError('Failed to load project details');
      console.error('Error fetching project:', err);
    } finally {
      setLoading(false);
    }
  };

  // In the component:
const location = useLocation();
  // Add after the fetchProject useEffect:
useEffect(() => {
  if (location.state?.message) {
    // You can show a snackbar or alert here
    alert(location.state.message);
  }
}, [location.state]);

// Update the submit proposal button action:
const handleSubmitProposal = () => {
  navigate(`/proposals/submit/${id}`);
};


  const handleDeleteProject = async () => {
  if (window.confirm('Are you sure you want to delete this project? This action cannot be undone.')) {
    try {
      await projectService.deleteProject(id);
      navigate('/projects/my');
    } catch (error) {
      console.error('Error deleting project:', error);
      alert('Failed to delete project');
    }
  }
};


  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorMessage error={error} />;
  if (!project) return <ErrorMessage error="Project not found" />;

  const isOwner = user?.id === project.client.id;
  const canSubmitProposal = user?.user_type === 'FREELANCER' && 
                           project.status === 'OPEN' && 
                           project.can_submit_proposal;

  return (
    <Container maxWidth="md">
      <Box sx={{ mt: 4, mb: 4 }}>
        <Paper elevation={3} sx={{ p: 4 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', mb: 3 }}>
            <Box>
              <Typography variant="h4" gutterBottom>
                {project.title}
              </Typography>
              <Chip 
                label={project.status} 
                color={project.status === 'OPEN' ? 'success' : 'default'}
              />
            </Box>
            
            {canSubmitProposal && (
              <Button 
                variant="contained" 
                size="large"
                onClick={handleSubmitProposal}
              >
                Submit Proposal
              </Button>
            )}
          </Box>

          <Grid container spacing={3} sx={{ mb: 3 }}>
            <Grid item xs={12} sm={6} md={3}>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <AttachMoney sx={{ mr: 1 }} />
                <Box>
                  <Typography variant="body2" color="text.secondary">
                    Budget
                  </Typography>
                  <Typography variant="subtitle1">
                    {project.budget_type === 'FIXED' ? 
                      formatCurrency(project.budget_amount) : 
                      `${formatCurrency(project.budget_amount)}/hr`
                    }
                  </Typography>
                </Box>
              </Box>
            </Grid>

            <Grid item xs={12} sm={6} md={3}>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <AccessTime sx={{ mr: 1 }} />
                <Box>
                  <Typography variant="body2" color="text.secondary">
                    Duration
                  </Typography>
                  <Typography variant="subtitle1">
                    {project.duration_in_days} days
                  </Typography>
                </Box>
              </Box>
            </Grid>

            <Grid item xs={12} sm={6} md={3}>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <CalendarToday sx={{ mr: 1 }} />
                <Box>
                  <Typography variant="body2" color="text.secondary">
                    Deadline
                  </Typography>
                  <Typography variant="subtitle1">
                    {formatDate(project.deadline)}
                  </Typography>
                </Box>
              </Box>
            </Grid>

            <Grid item xs={12} sm={6} md={3}>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <Work sx={{ mr: 1 }} />
                <Box>
                  <Typography variant="body2" color="text.secondary">
                    Proposals
                  </Typography>
                  <Typography variant="subtitle1">
                    {project.proposals_count || 0}
                  </Typography>
                </Box>
              </Box>
            </Grid>
          </Grid>

          <Divider sx={{ mb: 3 }} />

          <Box sx={{ mb: 3 }}>
            <Typography variant="h6" gutterBottom>
              Description
            </Typography>
            <Typography variant="body1" style={{ whiteSpace: 'pre-wrap' }}>
              {project.description}
            </Typography>
          </Box>

          <Box sx={{ mb: 3 }}>
            <Typography variant="h6" gutterBottom>
              Required Skills
            </Typography>
                       <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
              {project.required_skills.map((skill, index) => (
                <Chip 
                  key={index} 
                  label={skill} 
                  color="primary"
                  variant="outlined"
                />
              ))}
            </Box>
          </Box>

          <Divider sx={{ mb: 3 }} />

          <Box>
            <Typography variant="h6" gutterBottom>
              Posted By
            </Typography>
            <Box sx={{ display: 'flex', alignItems: 'center' }}>
              <Person sx={{ mr: 1 }} />
              <Box>
                <Typography variant="subtitle1">
                  {project.client.first_name} {project.client.last_name}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Posted on {formatDate(project.created_at)}
                </Typography>
              </Box>
            </Box>
          </Box>

          {isOwner && (
        <Box sx={{ mt: 4, display: 'flex', gap: 2 }}>
          {project.status === 'OPEN' && (
            <>
              <Button 
                variant="contained" 
                onClick={() => navigate(`/projects/${id}/proposals`)}
              >
                View Proposals ({project.proposals_count || 0})
              </Button>
              <Button 
                variant="outlined"
                color="primary"
                onClick={() => navigate(`/projects/${id}/edit`)}
              >
                Edit Project
              </Button>
              <Button 
                variant="outlined"
                color="error"
                onClick={handleDeleteProject}
              >
                Delete Project
              </Button>
            </>
          )}
          {project.status !== 'OPEN' && (
            <Button 
              variant="contained" 
              onClick={() => navigate(`/projects/${id}/proposals`)}
            >
              View Proposals ({project.proposals_count || 0})
            </Button>
          )}
        </Box>
      )}

              </Paper>
      </Box>
    </Container>
  );
};


export default ProjectDetail;




