import React, { useState, useEffect } from 'react';
import { Container, Box, Alert } from '@mui/material';
import { useParams, useNavigate } from 'react-router-dom';
import ReviewForm from '../../components/reviews/ReviewForm';
import LoadingSpinner from '../../components/common/LoadingSpinner';
import contractService from '../../services/contracts';

const SubmitReview = () => {
  const { contractId } = useParams();
  const navigate = useNavigate();
  const [contract, setContract] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchContract();
  }, [contractId]);

  const fetchContract = async () => {
    try {
      const data = await contractService.getContract(contractId);
      
      // Check if contract is completed
      if (data.status !== 'COMPLETED' && data.status !== 'Completed') {
        setError('Reviews can only be submitted for completed contracts');
        return;
      }

      // Check if user is part of the contract
      const currentUser = JSON.parse(localStorage.getItem('user'));
      if (currentUser.id !== data.client.id && currentUser.id !== data.freelancer.id) {
        setError('You are not authorized to review this contract');
        return;
      }

      setContract(data);
    } catch (error) {
      console.error('Error fetching contract:', error);
      setError('Failed to load contract details');
    } finally {
      setLoading(false);
    }
  };

  const handleSuccess = () => {
    navigate(`/contracts/${contractId}`, {
      state: { message: 'Review submitted successfully!' }
    });
  };

  const handleCancel = () => {
    navigate(`/contracts/${contractId}`);
  };

  if (loading) return <LoadingSpinner />;

  if (error) {
    return (
      <Container maxWidth="md">
        <Box sx={{ mt: 4 }}>
          <Alert severity="error">{error}</Alert>
        </Box>
            </Container>
    );
  }

  return (
    <Container maxWidth="md">
      <Box sx={{ mt: 4, mb: 4 }}>
        <ReviewForm
          contract={contract}
          onSuccess={handleSuccess}
          onCancel={handleCancel}
        />
      </Box>
    </Container>
  );
};

export default SubmitReview;