import React, { useState, useEffect } from 'react';
import {
  Container, Box, Typography, Paper, Tabs, Tab,
  Grid, Alert
} from '@mui/material';
import { useParams } from 'react-router-dom';
import ReviewCard from '../../components/reviews/ReviewCard';
import ReviewStats from '../../components/reviews/ReviewStats';
import LoadingSpinner from '../../components/common/LoadingSpinner';
import reviewService from '../../services/reviews';
import api from '../../services/api';

const UserReviews = () => {
  const { userId } = useParams();
  const [reviews, setReviews] = useState([]);
  const [stats, setStats] = useState(null);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [tabValue, setTabValue] = useState(0);

  useEffect(() => {
    fetchData();
  }, [userId]);

  const fetchData = async () => {
    try {
      const [reviewsData, statsData, userData] = await Promise.all([
        reviewService.getReviews({ reviewee: userId }),
        reviewService.getUserStats(userId),
        api.get(`/auth/users/${userId}/`)
      ]);

      setReviews(reviewsData.results || reviewsData);
      setStats(statsData);
      setUser(userData.data);
    } catch (error) {
      console.error('Error fetching reviews:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <LoadingSpinner />;

  const receivedReviews = reviews.filter(r => r.reviewee.id === parseInt(userId));
  const givenReviews = reviews.filter(r => r.reviewer.id === parseInt(userId));

  return (
    <Container maxWidth="lg">
      <Box sx={{ mt: 4, mb: 4 }}>
        <Typography variant="h4" gutterBottom>
          Reviews for {user?.first_name} {user?.last_name}
        </Typography>

        <Grid container spacing={3}>
          {/* Review Stats */}
          <Grid item xs={12} md={4}>
            {stats && <ReviewStats stats={stats} />}
          </Grid>

          {/* Reviews List */}
          <Grid item xs={12} md={8}>
            <Paper elevation={2}>
              <Tabs 
                value={tabValue} 
                onChange={(e, newValue) => setTabValue(newValue)}
                variant="fullWidth"
              >
                <Tab label={`Received (${receivedReviews.length})`} />
                <Tab label={`Given (${givenReviews.length})`} />
              </Tabs>

              <Box sx={{ p: 3 }}>
                {tabValue === 0 && (
                  <>
                    {receivedReviews.length === 0 ? (
                      <Typography color="text.secondary" align="center">
                        No reviews received yet
                      </Typography>
                    ) : (
                      receivedReviews.map((review) => (
                        <ReviewCard key={review.id} review={review} />
                      ))
                    )}
                  </>
                )}

                {tabValue === 1 && (
                  <>
                    {givenReviews.length === 0 ? (
                      <Typography color="text.secondary" align="center">
                        No reviews given yet
                      </Typography>
                    ) : (
                      givenReviews.map((review) => (
                        <ReviewCard key={review.id} review={review} />
                      ))
                    )}
                  </>
                )}
              </Box>
            </Paper>
          </Grid>
        </Grid>
      </Box>
    </Container>
  );
};

export default UserReviews;