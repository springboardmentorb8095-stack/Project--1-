import React, { useState, useEffect } from 'react';
import { 
  Box, Grid, Paper, Typography, Button, Chip
} from '@mui/material';
import { 
  Work, 
  Description, 
  AttachMoney, 
  Star,
  TrendingUp,
  Assignment
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import api from '../../services/api';
import { formatCurrency } from '../../services/utils';

const FreelancerDashboard = () => {
  const navigate = useNavigate();
  const [stats, setStats] = useState({
    total_proposals: 0,
    accepted_proposals: 0,
    acceptance_rate: 0,
    active_contracts: 0,
    completed_contracts: 0,
    total_earnings: 0,
    monthly_earnings: 0,
    average_rating: 0,
    matching_projects: 0
  });
  const [recentProposals, setRecentProposals] = useState([]);
  const [recentContracts, setRecentContracts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const response = await api.get('/dashboard/freelancer/');
      console.log('Dashboard response:', response.data); // Debug log
      setStats(response.data.statistics);
      setRecentProposals(response.data.recent_proposals || []);
      setRecentContracts(response.data.recent_contracts || []);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const StatCard = ({ icon, title, value, color = 'primary.main', subtitle }) => (
    <Paper sx={{ p: 3, height: '100%' }}>
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
        {icon}
        <Typography variant="h6" sx={{ ml: 1 }}>
          {title}
        </Typography>
      </Box>
      <Typography variant="h3" sx={{ color, mb: subtitle ? 1 : 0 }}>
        {value}
      </Typography>
      {subtitle && (
        <Typography variant="body2" color="text.secondary">
          {subtitle}
        </Typography>
      )}
    </Paper>
  );

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
        <Typography variant="h4">
          Freelancer Dashboard
        </Typography>
        
        <Button
          variant="contained"
          onClick={() => navigate('/projects')}
        >
          Browse Projects
        </Button>
      </Box>
      
      <Grid container spacing={3}>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard 
            icon={<Description color="primary" />}
            title="Total Proposals"
            value={stats.total_proposals}
            subtitle={`${stats.acceptance_rate}% acceptance rate`}
          />
        </Grid>
        
        <Grid item xs={12} sm={6} md={3}>
          <StatCard 
            icon={<Work color="success" />}
            title="Active Contracts"
            value={stats.active_contracts}
            color="success.main"
            subtitle={`${stats.completed_contracts} completed`}
          />
        </Grid>
        
        <Grid item xs={12} sm={6} md={3}>
          <StatCard 
            icon={<AttachMoney color="secondary" />}
            title="Total Earnings"
            value={formatCurrency(stats.total_earnings)}
            color="secondary.main"
            subtitle={`${formatCurrency(stats.monthly_earnings)} this month`}
          />
        </Grid>
        
        <Grid item xs={12} sm={6} md={3}>
          <StatCard 
            icon={<Star sx={{ color: '#f59e0b' }} />}
            title="Average Rating"
            value={stats.average_rating.toFixed(1)}
            color="#f59e0b"
            subtitle="out of 5.0"
          />
        </Grid>
      </Grid>

      {/* Quick Stats */}
      <Grid container spacing={3} sx={{ mt: 2 }}>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
              <TrendingUp color="info" />
              <Typography variant="h6" sx={{ ml: 1 }}>
                Proposal Performance
              </Typography>
            </Box>
            <Grid container spacing={2}>
              <Grid item xs={6}>
                <Typography variant="body2" color="text.secondary">
                  Accepted Proposals
                </Typography>
                <Typography variant="h5" color="success.main">
                  {stats.accepted_proposals}
                </Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography variant="body2" color="text.secondary">
                  Matching Projects
                </Typography>
                <Typography variant="h5" color="info.main">
                  {stats.matching_projects}
                </Typography>
              </Grid>
            </Grid>
          </Paper>
        </Grid>

        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
              <Assignment color="warning" />
              <Typography variant="h6" sx={{ ml: 1 }}>
                Recent Activity
              </Typography>
            </Box>
            <Typography variant="body2" paragraph>
              You have {recentProposals.filter(p => p.status === 'PENDING' || p.status === 'Pending').length} pending proposals
            </Typography>
            <Typography variant="body2">
              {recentContracts.filter(c => 
                c.status === 'ACTIVE' || c.status === 'Active'
              ).length} active contracts in progress
            </Typography>
          </Paper>
        </Grid>
      </Grid>

      {/* Recent Proposals */}
      {recentProposals.length > 0 && (
        <Paper sx={{ mt: 3, p: 3 }}>
          <Typography variant="h6" gutterBottom>
            Recent Proposals
          </Typography>
          {recentProposals.slice(0, 3).map((proposal) => {
            // Handle both old and new data structures
            const projectTitle = proposal.project_details?.title || 
                               proposal.project?.title || 
                               'Project';
            
            return (
              <Box 
                key={proposal.id} 
                sx={{ 
                  py: 1, 
                  borderBottom: '1px solid #e0e0e0',
                  '&:last-child': { borderBottom: 'none' }
                }}
              >
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Box>
                    <Typography variant="subtitle2">
                      {projectTitle}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {formatCurrency(proposal.proposed_rate)} • {proposal.estimated_duration} days
                    </Typography>
                  </Box>
                  <Chip
                    label={proposal.status}
                    size="small"
                    color={
                      proposal.status === 'ACCEPTED' ? 'success' :
                      proposal.status === 'PENDING' ? 'warning' : 'default'
                    }
                  />
                </Box>
              </Box>
            );
          })}
        </Paper>
      )}
      
      {/* Recent Contracts */}
      {recentContracts.length > 0 && (
        <Paper sx={{ mt: 3, p: 3 }}>
          <Typography variant="h6" gutterBottom>
            Recent Contracts
          </Typography>
          {recentContracts.slice(0, 3).map((contract) => (
            <Box 
              key={contract.id} 
              sx={{ 
                py: 1, 
                borderBottom: '1px solid #e0e0e0',
                '&:last-child': { borderBottom: 'none' }
              }}
            >
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <Box>
                  <Typography variant="subtitle2">
                    {contract.project?.title || 'Project'}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {formatCurrency(contract.total_amount || 0)} • 
                    Client: {contract.client?.first_name} {contract.client?.last_name || contract.client?.username || 'N/A'}
                  </Typography>
                </Box>
                <Chip
                  label={contract.status}
                  size="small"
                  color={
                    (contract.status === 'ACTIVE' || contract.status === 'Active') ? 'success' :
                    (contract.status === 'COMPLETED' || contract.status === 'Completed') ? 'info' : 
                    'default'
                  }
                />
              </Box>
            </Box>
          ))}
        </Paper>
      )}

      {/* Action Buttons */}
      <Box sx={{ mt: 4, display: 'flex', gap: 2, flexWrap: 'wrap' }}>
        <Button 
          variant="outlined" 
          onClick={() => navigate('/projects')}
        >
          Find Projects
        </Button>
        <Button 
          variant="outlined" 
          onClick={() => navigate('/proposals/my')}
        >
          My Proposals
        </Button>
        <Button 
          variant="outlined" 
          onClick={() => navigate('/contracts')}
        >
          My Contracts
        </Button>
        <Button 
          variant="outlined" 
          onClick={() => navigate('/profile')}
        >
          Update Profile
        </Button>
      </Box>
    </Box>
  );
};

export default FreelancerDashboard;