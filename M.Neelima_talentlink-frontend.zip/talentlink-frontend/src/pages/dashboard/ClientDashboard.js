import React, { useState, useEffect } from 'react';
import { Box, Grid, Paper, Typography, Button } from '@mui/material';
import { Add, Work, Description, AttachMoney } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';  // Make sure this is imported
import api from '../../services/api';
import { formatCurrency } from '../../services/utils';

const ClientDashboard = () => {
  const navigate = useNavigate();  // Make sure this is declared
  const [stats, setStats] = useState({
    total_projects: 0,
    open_projects: 0,
    in_progress_projects: 0,
    completed_projects: 0,
    total_proposals_received: 0,
    pending_proposals: 0,
    total_spent: 0,
    active_contracts_value: 0
  });

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const response = await api.get('/dashboard/client/');
      setStats(response.data.statistics);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    }
  };

  const handleCreateProject = () => {
    console.log('Create project clicked');  // Debug log
    navigate('/projects/create');
  };

  const StatCard = ({ icon, title, value, color = 'primary.main' }) => (
    <Paper sx={{ p: 3, height: '100%' }}>
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
        {icon}
        <Typography variant="h6" sx={{ ml: 1 }}>
          {title}
        </Typography>
      </Box>
      <Typography variant="h3" sx={{ color }}>
        {value}
      </Typography>
    </Paper>
  );

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
        <Typography variant="h4">
          Client Dashboard
        </Typography>
        
        <Button
          variant="contained"
          startIcon={<Add />}
          onClick={handleCreateProject}
          size="large"
        >
          Create Project
        </Button>
      </Box>
      
      <Grid container spacing={3}>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard 
            icon={<Work color="primary" />}
            title="Total Projects"
            value={stats.total_projects}
          />
        </Grid>
        
        <Grid item xs={12} sm={6} md={3}>
          <StatCard 
            icon={<Work color="success" />}
            title="Open Projects"
            value={stats.open_projects}
            color="success.main"
          />
        </Grid>
        
        <Grid item xs={12} sm={6} md={3}>
          <StatCard 
            icon={<Description color="info" />}
            title="Proposals Received"
            value={stats.total_proposals_received}
            color="info.main"
          />
        </Grid>
        
        <Grid item xs={12} sm={6} md={3}>
          <StatCard 
            icon={<AttachMoney color="secondary" />}
            title="Total Spent"
            value={formatCurrency(stats.total_spent)}
            color="secondary.main"
          />
        </Grid>
      </Grid>

      <Box sx={{ mt: 4, display: 'flex', gap: 2 }}>
        <Button variant="outlined" onClick={() => navigate('/projects/my')}>
          View My Projects
        </Button>
        <Button variant="outlined" onClick={() => navigate('/projects')}>
          Browse All Projects
        </Button>
      </Box>
    </Box>
  );
};
export default ClientDashboard;