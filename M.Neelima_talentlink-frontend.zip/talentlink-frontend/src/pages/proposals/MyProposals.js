import React, { useState, useEffect } from 'react';
import {
  Container, Box, Typography, Paper, Tab, Tabs,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  Chip, Button, IconButton
} from '@mui/material';
import { Visibility } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import LoadingSpinner from '../../components/common/LoadingSpinner';
import proposalService from '../../services/proposals';
import { formatCurrency, formatDate } from '../../services/utils';

const MyProposals = () => {
  const navigate = useNavigate();
  const [proposals, setProposals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tabValue, setTabValue] = useState(0);

  useEffect(() => {
    fetchMyProposals();
  }, []);

  const fetchMyProposals = async () => {
    try {
      const data = await proposalService.getProposals();
      console.log('Proposals data:', data); // Debug log
      setProposals(data.results || data);
    } catch (error) {
      console.error('Error fetching proposals:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      'PENDING': 'warning',
      'ACCEPTED': 'success',
      'REJECTED': 'error',
      'WITHDRAWN': 'default'
    };
    return colors[status] || 'default';
  };

  const filterProposals = (status) => {
    if (status === 'all') return proposals;
    return proposals.filter(p => p.status === status);
  };

  if (loading) return <LoadingSpinner />;

  const pendingProposals = filterProposals('PENDING');
  const acceptedProposals = filterProposals('ACCEPTED');
  const rejectedProposals = filterProposals('REJECTED');

  const getProjectData = (proposal) => {
    // Handle both old and new data structures
    return proposal.project_details || proposal.project || {};
  };

  return (
    <Container maxWidth="lg">
      <Box sx={{ mt: 4, mb: 4 }}>
        <Typography variant="h4" gutterBottom>
          My Proposals
        </Typography>

        <Paper elevation={3}>
          <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
            <Tabs value={tabValue} onChange={(e, newValue) => setTabValue(newValue)}>
              <Tab label={`Pending (${pendingProposals.length})`} />
              <Tab label={`Accepted (${acceptedProposals.length})`} />
              <Tab label={`Rejected (${rejectedProposals.length})`} />
              <Tab label={`All (${proposals.length})`} />
            </Tabs>
          </Box>

          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Project</TableCell>
                  <TableCell>Client</TableCell>
                  <TableCell>Proposed Rate</TableCell>
                  <TableCell>Duration</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell>Submitted</TableCell>
                  <TableCell>Action</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {(tabValue === 0 ? pendingProposals :
                  tabValue === 1 ? acceptedProposals :
                  tabValue === 2 ? rejectedProposals : proposals
                ).map((proposal) => {
                  const projectData = getProjectData(proposal);
                  const clientData = projectData.client || {};
                  
                  return (
                    <TableRow key={proposal.id}>
                      <TableCell>{projectData.title || 'Project'}</TableCell>
                      <TableCell>
                        {clientData.first_name || ''} {clientData.last_name || clientData.username || 'N/A'}
                      </TableCell>
                      <TableCell>
                        {formatCurrency(proposal.proposed_rate)}
                        {projectData.budget_type === 'HOURLY' && '/hr'}
                      </TableCell>
                      <TableCell>{proposal.estimated_duration} days</TableCell>
                      <TableCell>
                        <Chip
                          label={proposal.status}
                          color={getStatusColor(proposal.status)}
                          size="small"
                        />
                      </TableCell>
                      <TableCell>{formatDate(proposal.created_at)}</TableCell>
                      <TableCell>
                        <IconButton
                          size="small"
                          onClick={() => navigate(`/projects/${proposal.project || projectData.id}`)}
                          title="View Project"
                        >
                          <Visibility />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </TableContainer>

          {(tabValue === 0 ? pendingProposals :
            tabValue === 1 ? acceptedProposals :
            tabValue === 2 ? rejectedProposals : proposals
          ).length === 0 && (
            <Box sx={{ p: 3, textAlign: 'center' }}>
              <Typography color="text.secondary">
                No proposals found
              </Typography>
            </Box>
          )}
        </Paper>
      </Box>
    </Container>
  );
};

export default MyProposals;