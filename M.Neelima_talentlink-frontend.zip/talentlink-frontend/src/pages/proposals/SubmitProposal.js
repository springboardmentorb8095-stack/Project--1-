import React from 'react';
import { Container, Box } from '@mui/material';
import SubmitProposalForm from '../../components/proposals/SubmitProposalForm';

const SubmitProposal = () => {
  return (
    <Container maxWidth="md">
      <Box sx={{ mt: 4, mb: 4 }}>
        <SubmitProposalForm />
      </Box>
    </Container>
  );
};

export default SubmitProposal;