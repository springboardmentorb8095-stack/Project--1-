import React, { useState, useEffect } from 'react';
import {
  Container, Box, Typography, Paper, Alert, Tab, Tabs
} from '@mui/material';
import { useParams, useNavigate } from 'react-router-dom';
import ProposalCard from '../../components/proposals/ProposalCard';
import AcceptProposalDialog from '../../components/proposals/AcceptProposalDialog';
import LoadingSpinner from '../../components/common/LoadingSpinner';
import proposalService from '../../services/proposals';
import projectService from '../../services/projects';

const ProjectProposals = () => {
  const { projectId } = useParams();
  const navigate = useNavigate();
  const [project, setProject] = useState(null);
  const [proposals, setProposals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [tabValue, setTabValue] = useState(0);
  const [selectedProposal, setSelectedProposal] = useState(null);
  const [acceptDialogOpen, setAcceptDialogOpen] = useState(false);

  useEffect(() => {
    fetchData();
  }, [projectId]);

  const fetchData = async () => {
    try {
      const [projectData, proposalsData] = await Promise.all([
        projectService.getProject(projectId),
        proposalService.getProjectProposals(projectId)
      ]);

      // Verify user is the project owner
      const currentUser = JSON.parse(localStorage.getItem('user'));
      if (projectData.client.id !== currentUser.id) {
        setError('You are not authorized to view these proposals');
        return;
      }

      setProject(projectData);
      setProposals(proposalsData.results || proposalsData);
    } catch (error) {
      console.error('Error fetching data:', error);
      setError('Failed to load proposals');
    } finally {
      setLoading(false);
    }
  };

  const handleAcceptProposal = (proposal) => {
    setSelectedProposal(proposal);
    setAcceptDialogOpen(true);
  };

  const confirmAcceptProposal = async (contractData) => {
    try {
      await proposalService.acceptProposal(selectedProposal.id, contractData);
      navigate(`/projects/${projectId}`, {
        state: { message: 'Proposal accepted and contract created!' }
      });
    } catch (error) {
      console.error('Error accepting proposal:', error);
      alert('Failed to accept proposal');
    }
  };

  const handleRejectProposal = async (proposal) => {
    if (window.confirm('Are you sure you want to reject this proposal?')) {
      try {
        await proposalService.rejectProposal(proposal.id);
        // Refresh proposals
        fetchData();
      } catch (error) {
        console.error('Error rejecting proposal:', error);
        alert('Failed to reject proposal');
      }
    }
  };

  const filterProposals = (status) => {
    if (status === 'all') return proposals;
    return proposals.filter(p => p.status === status);
  };

  if (loading) return <LoadingSpinner />;

  if (error) {
    return (
      <Container maxWidth="md">
        <Box sx={{ mt: 4 }}>
          <Alert severity="error">{error}</Alert>
        </Box>
      </Container>
    );
  }

  const pendingProposals = filterProposals('PENDING');
  const acceptedProposals = filterProposals('ACCEPTED');
  const rejectedProposals = filterProposals('REJECTED');

  return (
    <Container maxWidth="md">
      <Box sx={{ mt: 4, mb: 4 }}>
        <Paper elevation={3} sx={{ p: 4 }}>
          <Typography variant="h5" gutterBottom>
            Proposals for: {project?.title}
          </Typography>
          
          <Typography variant="body2" color="text.secondary" paragraph>
            Total Proposals: {proposals.length}
          </Typography>

          <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
            <Tabs value={tabValue} onChange={(e, newValue) => setTabValue(newValue)}>
              <Tab label={`Pending (${pendingProposals.length})`} />
              <Tab label={`Accepted (${acceptedProposals.length})`} />
              <Tab label={`Rejected (${rejectedProposals.length})`} />
              <Tab label={`All (${proposals.length})`} />
            </Tabs>
          </Box>

          {tabValue === 0 && (
            <Box>
              {pendingProposals.length === 0 ? (
                <Typography color="text.secondary">No pending proposals</Typography>
              ) : (
                pendingProposals.map(proposal => (
                  <ProposalCard
                    key={proposal.id}
                    proposal={proposal}
                    onAccept={handleAcceptProposal}
                    onReject={handleRejectProposal}
                    isClient={true}
                  />
                ))
              )}
            </Box>
          )}

          {tabValue === 1 && (
            <Box>
              {acceptedProposals.length === 0 ? (
                <Typography color="text.secondary">No accepted proposals</Typography>
              ) : (
                acceptedProposals.map(proposal => (
                  <ProposalCard
                    key={proposal.id}
                    proposal={proposal}
                    isClient={true}
                  />
                ))
              )}
            </Box>
          )}

          {tabValue === 2 && (
            <Box>
              {rejectedProposals.length === 0 ? (
                <Typography color="text.secondary">No rejected proposals</Typography>
              ) : (
                rejectedProposals.map(proposal => (
                  <ProposalCard
                    key={proposal.id}
                    proposal={proposal}
                    isClient={true}
                  />
                ))
              )}
            </Box>
          )}

          {tabValue === 3 && (
            <Box>
              {proposals.map(proposal => (
                <ProposalCard
                  key={proposal.id}
                  proposal={proposal}
                  onAccept={handleAcceptProposal}
                  onReject={handleRejectProposal}
                  isClient={true}
                />
              ))}
            </Box>
          )}
        </Paper>
      </Box>

      <AcceptProposalDialog
        open={acceptDialogOpen}
        onClose={() => setAcceptDialogOpen(false)}
        onConfirm={confirmAcceptProposal}
        proposal={selectedProposal}
      />
    </Container>
  );
};

export default ProjectProposals;