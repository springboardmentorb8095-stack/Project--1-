import React from 'react';
import { Box, Container, Typography } from '@mui/material';
import { useAuth } from '../../context/AuthContext';
import FreelancerProfileForm from '../../components/profile/FreelancerProfileForm';
import ClientProfileForm from '../../components/profile/ClientProfileForm';

const Profile = () => {
  const { user } = useAuth();

  return (
    <Container maxWidth="md">
      <Box sx={{ mt: 4, mb: 4 }}>
        <Typography variant="h4" gutterBottom>
          My Profile
        </Typography>
        
        {user?.user_type === 'FREELANCER' ? (
          <FreelancerProfileForm />
        ) : (
          <ClientProfileForm />
        )}
      </Box>
    </Container>
  );
};

export default Profile;