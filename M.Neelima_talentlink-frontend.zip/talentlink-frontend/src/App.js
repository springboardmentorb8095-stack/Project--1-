import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider, createTheme, CssBaseline } from '@mui/material';
import { AuthProvider, useAuth } from './context/AuthContext';

// Components
import Layout from './components/common/Layout';
import PrivateRoute from './components/common/PrivateRoute';
import SubmitReview from './pages/reviews/SubmitReview';
import UserReviews from './pages/reviews/UserReviews';


// Pages
import Login from './pages/auth/Login';
import Register from './pages/auth/Register';
import ClientDashboard from './pages/dashboard/ClientDashboard';
import FreelancerDashboard from './pages/dashboard/FreelancerDashboard';
import Profile from './pages/profile/Profile';

// Project Pages
import ProjectList from './pages/projects/ProjectList';
import ProjectDetail from './pages/projects/ProjectDetail';
import CreateProject from './pages/projects/CreateProject';
import MyProjects from './pages/projects/MyProjects';
import EditProject from './pages/projects/EditProject';


import SubmitProposal from './pages/proposals/SubmitProposal';
import ProjectProposals from './pages/proposals/ProjectProposals';
import MyProposals from './pages/proposals/MyProposals';

import ContractList from './pages/contracts/ContractList';
import ContractDetail from './pages/contracts/ContractDetail';

import Messages from './pages/messaging/Messages';

const theme = createTheme({
  palette: {
    primary: {
      main: '#1976d2',
    },
    secondary: {
      main: '#dc004e',
    },
  },
});

function DashboardRouter() {
  const { user } = useAuth();

  if (user?.user_type === 'CLIENT') {
    return <ClientDashboard />;
  } else if (user?.user_type === 'FREELANCER') {
    return <FreelancerDashboard />;
  }

  return <Navigate to="/login" />;
}

function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <AuthProvider>
        <Router>
          <Layout>
            <Routes>
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              
              <Route
                path="/profile"
                element={
                  <PrivateRoute>
                    <Profile />
                  </PrivateRoute>
                }
              />
              
              <Route
                path="/dashboard"
                element={
                  <PrivateRoute>
                    <DashboardRouter />
                  </PrivateRoute>
                }
              />

              {/* Project Routes - Order matters! Specific routes first */}
              <Route
                path="/projects/create"
                element={
                  <PrivateRoute allowedRoles={['CLIENT']}>
                    <CreateProject />
                  </PrivateRoute>
                }
              />
              <Route
                path="/projects/:id/edit"
                element={
                  <PrivateRoute allowedRoles={['CLIENT']}>
                    <EditProject />
                  </PrivateRoute>
                }
              />

              <Route
                path="/projects/my"
                element={
                  <PrivateRoute allowedRoles={['CLIENT']}>
                    <MyProjects />
                  </PrivateRoute>
                }
              />

              <Route
                path="/projects/:id"
                element={
                  <PrivateRoute>
                    <ProjectDetail />
                  </PrivateRoute>
                }
              />

              <Route
                path="/projects"
                element={
                  <PrivateRoute>
                    <ProjectList />
                  </PrivateRoute>
                }
              />

              <Route
                path="/proposals/submit/:projectId"
                element={
                  <PrivateRoute allowedRoles={['FREELANCER']}>
                    <SubmitProposal />
                  </PrivateRoute>
                }
              />

              <Route
                path="/projects/:projectId/proposals"
                element={
                  <PrivateRoute allowedRoles={['CLIENT']}>
                    <ProjectProposals />
                  </PrivateRoute>
                }
              />

              <Route
                path="/proposals/my"
                element={
                  <PrivateRoute allowedRoles={['FREELANCER']}>
                    <MyProposals />
                  </PrivateRoute>
                }
              />

              <Route
              path="/contracts"
              element={
                <PrivateRoute>
                  <ContractList />
                </PrivateRoute>
              }
            />

            <Route
              path="/contracts/:id"
              element={
                <PrivateRoute>
                  <ContractDetail />
                </PrivateRoute>
              }
            />
            <Route
                path="/messages"
                element={
                  <PrivateRoute>
                    <Messages />
                  </PrivateRoute>
                }
              />

              <Route
              path="/reviews/submit/:contractId"
              element={
                <PrivateRoute>
                  <SubmitReview />
                </PrivateRoute>
              }
            />

            <Route
              path="/reviews/user/:userId"
              element={
                <PrivateRoute>
                  <UserReviews />
                </PrivateRoute>
              }
            />
              
              <Route path="/" element={<Navigate to="/dashboard" />} />
            </Routes>
          </Layout>
        </Router>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;