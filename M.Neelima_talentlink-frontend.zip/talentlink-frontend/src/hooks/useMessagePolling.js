import { useEffect, useRef } from 'react';
import messagingService from '../services/messaging';

const useMessagePolling = (conversationId, onNewMessages, interval = 5000) => {
  const intervalRef = useRef(null);
  const lastMessageIdRef = useRef(null);

  useEffect(() => {
    if (!conversationId) return;

    const pollMessages = async () => {
      try {
        const messages = await messagingService.getMessages(conversationId);
        const newMessages = messages.filter(
          msg => !lastMessageIdRef.current || msg.id > lastMessageIdRef.current
        );

        if (newMessages.length > 0) {
          lastMessageIdRef.current = Math.max(...newMessages.map(m => m.id));
          onNewMessages(newMessages);
        }
      } catch (error) {
        console.error('Error polling messages:', error);
      }
    };

    // Initial poll
    pollMessages();

    // Set up interval
    intervalRef.current = setInterval(pollMessages, interval);

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [conversationId, interval]);
};

export default useMessagePolling;