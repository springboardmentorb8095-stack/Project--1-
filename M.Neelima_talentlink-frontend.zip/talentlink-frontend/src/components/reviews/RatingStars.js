import React from 'react';
import { Box, IconButton } from '@mui/material';
import { Star, StarBorder, StarHalf } from '@mui/icons-material';

const RatingStars = ({ 
  value = 0, 
  onChange = null, 
  size = 'medium', 
  readOnly = false,
  showValue = false,
  precision = 1 
}) => {
  const sizes = {
    small: 20,
    medium: 24,
    large: 32
  };

  const starSize = sizes[size] || sizes.medium;

  const handleClick = (rating) => {
    if (!readOnly && onChange) {
      onChange(rating);
    }
  };

  const renderStar = (index) => {
    const rating = index + 1;
    
    if (readOnly) {
      // For display only
      if (value >= rating) {
        return <Star sx={{ fontSize: starSize, color: '#f59e0b' }} />;
      } else if (value >= rating - 0.5) {
        return <StarHalf sx={{ fontSize: starSize, color: '#f59e0b' }} />;
      } else {
        return <StarBorder sx={{ fontSize: starSize, color: '#f59e0b' }} />;
      }
    } else {
      // For input
      return (
        <IconButton
          onClick={() => handleClick(rating)}
          sx={{ p: 0.5 }}
        >
          {value >= rating ? 
            <Star sx={{ fontSize: starSize, color: '#f59e0b' }} /> : 
            <StarBorder sx={{ fontSize: starSize, color: '#f59e0b' }} />
          }
        </IconButton>
      );
    }
  };

  return (
    <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
      {[0, 1, 2, 3, 4].map((index) => (
        <Box key={index}>
          {renderStar(index)}
        </Box>
      ))}
      {showValue && (
        <Box sx={{ ml: 1, fontSize: starSize * 0.7 }}>
          {value.toFixed(1)}
        </Box>
      )}
    </Box>
  );
};

export default RatingStars;