import React from 'react';
import {
  Card, CardContent, Box, Typography, Avatar, Chip
} from '@mui/material';
import { Person } from '@mui/icons-material';
import RatingStars from './RatingStars';
import { formatDate } from '../../services/utils';

const ReviewCard = ({ review }) => {
  const getReviewerType = () => {
    // Determine if reviewer is client or freelancer based on the contract
    if (review.reviewer.id === review.contract?.client?.id) {
      return 'Client';
    }
    return 'Freelancer';
  };

  return (
    <Card elevation={1} sx={{ mb: 2 }}>
      <CardContent>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
          <Box sx={{ display: 'flex', gap: 2, alignItems: 'center' }}>
            <Avatar>
              <Person />
            </Avatar>
            <Box>
              <Typography variant="subtitle1">
                {review.reviewer.first_name} {review.reviewer.last_name}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {getReviewerType()} • {formatDate(review.created_at)}
              </Typography>
            </Box>
          </Box>
          <RatingStars value={review.rating} readOnly size="small" />
        </Box>

        <Typography variant="body1" paragraph>
          {review.comment}
        </Typography>

        {review.contract && (
          <Box sx={{ mt: 2 }}>
            <Typography variant="caption" color="text.secondary">
              Project: {review.contract.project?.title || 'N/A'}
            </Typography>
          </Box>
        )}
      </CardContent>
    </Card>
  );
};

export default ReviewCard;