import React from 'react';
import {
  Box, Paper, Typography, LinearProgress, Grid
} from '@mui/material';
import RatingStars from './RatingStars';

const ReviewStats = ({ stats }) => {
  const { total_reviews, average_rating, rating_breakdown } = stats;

  const getPercentage = (count) => {
    return total_reviews > 0 ? (count / total_reviews) * 100 : 0;
  };

  return (
    <Paper elevation={2} sx={{ p: 3 }}>
      <Typography variant="h6" gutterBottom>
        Rating Overview
      </Typography>

      <Box sx={{ textAlign: 'center', my: 3 }}>
        <Typography variant="h2" sx={{ fontWeight: 'bold' }}>
          {average_rating.toFixed(1)}
        </Typography>
        <RatingStars value={average_rating} readOnly size="large" />
        <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
          Based on {total_reviews} review{total_reviews !== 1 ? 's' : ''}
        </Typography>
      </Box>

      <Box sx={{ mt: 3 }}>
        {[5, 4, 3, 2, 1].map((rating) => (
          <Box key={rating} sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
            <Typography sx={{ minWidth: 20 }}>{rating}</Typography>
            <RatingStars value={1} readOnly size="small" />
            <Box sx={{ flexGrow: 1, mx: 2 }}>
              <LinearProgress
                variant="determinate"
                value={getPercentage(rating_breakdown[rating])}
                sx={{ height: 8, borderRadius: 4 }}
              />
            </Box>
            <Typography sx={{ minWidth: 40, textAlign: 'right' }}>
              {rating_breakdown[rating]}
            </Typography>
          </Box>
        ))}
      </Box>
    </Paper>
  );
};

export default ReviewStats;