import React, { useState } from 'react';
import {
  Box, Paper, Typography, TextField, Button, Alert,
  Divider, Avatar
} from '@mui/material';
import { Person } from '@mui/icons-material';
import RatingStars from './RatingStars';
import reviewService from '../../services/reviews';

const ReviewForm = ({ contract, onSuccess, onCancel }) => {
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const currentUser = JSON.parse(localStorage.getItem('user'));
  const isClient = currentUser.id === contract.client.id;
  const reviewee = isClient ? contract.freelancer : contract.client;

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (rating === 0) {
      setError('Please select a rating');
      return;
    }

    if (comment.trim().length < 10) {
      setError('Please write at least 10 characters in your review');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const reviewData = {
        contract_id: contract.id,
        rating,
        comment: comment.trim()
      };

      await reviewService.submitReview(reviewData);
      
      if (onSuccess) {
        onSuccess();
      }
    } catch (error) {
      console.error('Error submitting review:', error);
      setError(error.response?.data?.detail || 'Failed to submit review');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Paper elevation={3} sx={{ p: 3, maxWidth: 600, mx: 'auto' }}>
      <Typography variant="h5" gutterBottom>
        Review {isClient ? 'Freelancer' : 'Client'}
      </Typography>

      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, my: 3 }}>
        <Avatar>
          <Person />
        </Avatar>
        <Box>
          <Typography variant="subtitle1">
            {reviewee.first_name} {reviewee.last_name}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            @{reviewee.username}
          </Typography>
        </Box>
      </Box>

      <Divider sx={{ my: 3 }} />

      <Box component="form" onSubmit={handleSubmit}>
        {error && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        )}

        <Box sx={{ mb: 3 }}>
          <Typography variant="subtitle1" gutterBottom>
            Rating *
          </Typography>
          <RatingStars
            value={rating}
            onChange={setRating}
            size="large"
          />
          <Typography variant="caption" color="text.secondary">
            Click on stars to rate
          </Typography>
        </Box>

        <TextField
          fullWidth
          label="Your Review"
          multiline
          rows={4}
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          margin="normal"
          required
          placeholder={`Share your experience working with ${reviewee.first_name}...`}
          helperText={`${comment.length}/500 characters`}
          inputProps={{ maxLength: 500 }}
        />

        <Box sx={{ mt: 3, display: 'flex', gap: 2 }}>
          <Button
            type="submit"
            variant="contained"
            fullWidth
            disabled={loading}
          >
            {loading ? 'Submitting...' : 'Submit Review'}
          </Button>
          <Button
            variant="outlined"
            fullWidth
            onClick={onCancel}
            disabled={loading}
          >
            Cancel
          </Button>
        </Box>
      </Box>
    </Paper>
  );
};

export default ReviewForm;