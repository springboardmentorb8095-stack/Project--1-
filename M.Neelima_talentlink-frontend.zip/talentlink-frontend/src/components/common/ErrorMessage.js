import React from 'react';
import { Alert, AlertTitle } from '@mui/material';

const ErrorMessage = ({ error, title = "Error" }) => {
  return (
    <Alert severity="error">
      <AlertTitle>{title}</AlertTitle>
      {error}
    </Alert>
  );
};

export default ErrorMessage;