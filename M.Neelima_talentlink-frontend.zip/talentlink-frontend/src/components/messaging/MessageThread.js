import React, { useState, useEffect, useRef } from 'react';
import {
  Box, Paper, Typography, TextField, IconButton, Avatar,
  List, ListItem, CircularProgress, Divider
} from '@mui/material';
import { Send, Person } from '@mui/icons-material';
import { formatDate } from '../../services/utils';
import messagingService from '../../services/messaging';

const MessageThread = ({ conversation, onNewMessage }) => {
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const messagesEndRef = useRef(null);
  const currentUser = JSON.parse(localStorage.getItem('user'));

  useEffect(() => {
    if (conversation) {
      fetchMessages();
      markAsRead();
    }
  }, [conversation]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const fetchMessages = async () => {
    setLoading(true);
    try {
      const data = await messagingService.getMessages(conversation.id);
      setMessages(data.results || data);
    } catch (error) {
      console.error('Error fetching messages:', error);
    } finally {
      setLoading(false);
    }
  };

  const markAsRead = async () => {
    try {
      await messagingService.markMessagesAsRead(conversation.id);
    } catch (error) {
      console.error('Error marking messages as read:', error);
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = async (e) => {
    e.preventDefault();
    
    if (!newMessage.trim() || sending) return;

    setSending(true);
    try {
      const messageData = {
        conversation: conversation.id,
        content: newMessage.trim()
      };
      
      const sentMessage = await messagingService.sendMessage(messageData);
      setMessages([...messages, sentMessage]);
      setNewMessage('');
      
      // Notify parent component
      if (onNewMessage) {
        onNewMessage(sentMessage);
      }
    } catch (error) {
      console.error('Error sending message:', error);
      alert('Failed to send message');
    } finally {
      setSending(false);
    }
  };

  if (!conversation) {
    return (
      <Box sx={{ p: 3, textAlign: 'center' }}>
        <Typography color="text.secondary">
          Select a conversation to start messaging
        </Typography>
      </Box>
    );
  }

  const otherUser = conversation.other_user;

  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      {/* Header */}
      <Paper elevation={1} sx={{ p: 2, borderRadius: 0 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
          <Avatar>
            <Person />
          </Avatar>
          <Box sx={{ flexGrow: 1 }}>
            <Typography variant="h6">
              {otherUser?.first_name} {otherUser?.last_name}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              {conversation.contract?.project?.title || 'Contract Discussion'}
            </Typography>
          </Box>
        </Box>
      </Paper>

      <Divider />

      {/* Messages */}
      <Box sx={{ flexGrow: 1, overflow: 'auto', p: 2, bgcolor: '#f5f5f5' }}>
        {loading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', p: 3 }}>
            <CircularProgress />
          </Box>
        ) : (
          <List>
            {messages.map((message, index) => {
              const isOwnMessage = message.sender.id === currentUser.id;
              const showDate = index === 0 || 
                new Date(messages[index - 1].created_at).toDateString() !== 
                new Date(message.created_at).toDateString();

              return (
                <React.Fragment key={message.id}>
                  {showDate && (
                    <Box sx={{ textAlign: 'center', my: 2 }}>
                      <Typography variant="caption" color="text.secondary">
                        {formatDate(message.created_at)}
                      </Typography>
                    </Box>
                  )}
                  
                  <ListItem
                    sx={{
                      flexDirection: isOwnMessage ? 'row-reverse' : 'row',
                      gap: 1,
                      px: 0
                    }}
                  >
                    <Avatar sx={{ width: 32, height: 32 }}>
                      {message.sender.first_name?.[0] || message.sender.username?.[0]}
                    </Avatar>
                    
                    <Paper
                      elevation={1}
                      sx={{
                        p: 2,
                        maxWidth: '70%',
                        bgcolor: isOwnMessage ? 'primary.main' : 'background.paper',
                        color: isOwnMessage ? 'primary.contrastText' : 'text.primary',
                        borderRadius: 2
                      }}
                    >
                      <Typography variant="body1" sx={{ whiteSpace: 'pre-wrap' }}>
                        {message.content}
                      </Typography>
                      <Typography
                        variant="caption"
                        sx={{
                          display: 'block',
                          mt: 0.5,
                          opacity: 0.7,
                          color: isOwnMessage ? 'primary.contrastText' : 'text.secondary'
                        }}
                      >
                        {new Date(message.created_at).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </Typography>
                    </Paper>
                  </ListItem>
                </React.Fragment>
              );
            })}
            <div ref={messagesEndRef} />
          </List>
        )}
      </Box>

      <Divider />

      {/* Message Input */}
      <Paper elevation={1} sx={{ p: 2, borderRadius: 0 }}>
        <form onSubmit={handleSendMessage}>
          <Box sx={{ display: 'flex', gap: 1 }}>
            <TextField
              fullWidth
              placeholder="Type a message..."
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              variant="outlined"
              size="small"
              disabled={sending}
              multiline
              maxRows={4}
            />
            <IconButton
              type="submit"
              color="primary"
              disabled={!newMessage.trim() || sending}
            >
              <Send />
            </IconButton>
          </Box>
        </form>
      </Paper>
    </Box>
  );
};

export default MessageThread;