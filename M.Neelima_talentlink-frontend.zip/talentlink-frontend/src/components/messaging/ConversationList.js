import React from 'react';
import {
  List, ListItem, ListItemAvatar, ListItemText, Avatar,
  Typography, Badge, Box, Chip, IconButton
} from '@mui/material';
import { Person, Circle } from '@mui/icons-material';
import { formatDate } from '../../services/utils';

const ConversationList = ({ conversations, selectedConversation, onSelectConversation }) => {
  const getCurrentUser = () => JSON.parse(localStorage.getItem('user'));

  const getOtherUser = (conversation) => {
    const currentUser = getCurrentUser();
    return conversation.other_user;
  };

  const getConversationTitle = (conversation) => {
    if (conversation.contract?.project?.title) {
      return conversation.contract.project.title;
    }
    return 'Contract Discussion';
  };

  return (
    <List sx={{ width: '100%', bgcolor: 'background.paper' }}>
      {conversations.length === 0 ? (
        <Box sx={{ p: 3, textAlign: 'center' }}>
          <Typography color="text.secondary">
            No conversations yet
          </Typography>
        </Box>
      ) : (
        conversations.map((conversation) => {
          const otherUser = getOtherUser(conversation);
          const isSelected = selectedConversation?.id === conversation.id;
          const hasUnread = conversation.unread_count > 0;

          return (
            <ListItem
              key={conversation.id}
              alignItems="flex-start"
              selected={isSelected}
              onClick={() => onSelectConversation(conversation)}
              sx={{
                cursor: 'pointer',
                '&:hover': { bgcolor: 'action.hover' },
                borderBottom: '1px solid #e0e0e0'
              }}
              secondaryAction={
                hasUnread && (
                  <Badge badgeContent={conversation.unread_count} color="primary" />
                )
              }
            >
              <ListItemAvatar>
                <Avatar>
                  <Person />
                </Avatar>
              </ListItemAvatar>
              
              <ListItemText
                primary={
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Typography variant="subtitle1" component="span">
                      {otherUser?.first_name} {otherUser?.last_name}
                    </Typography>
                    {hasUnread && (
                      <Circle sx={{ fontSize: 8, color: 'primary.main' }} />
                    )}
                  </Box>
                }
                secondary={
                  <>
                    <Typography
                      component="span"
                      variant="body2"
                      color="text.secondary"
                      sx={{ display: 'block', mb: 0.5 }}
                    >
                      {getConversationTitle(conversation)}
                    </Typography>
                    
                    {conversation.last_message && (
                      <Typography
                        component="span"
                        variant="body2"
                        color={hasUnread ? 'text.primary' : 'text.secondary'}
                        sx={{
                          display: 'block',
                          fontWeight: hasUnread ? 600 : 400,
                          overflow: 'hidden',
                          textOverflow: 'ellipsis',
                          whiteSpace: 'nowrap'
                        }}
                      >
                        {conversation.last_message.sender.id === getCurrentUser().id ? 'You: ' : ''}
                        {conversation.last_message.content}
                      </Typography>
                    )}
                    
                    <Typography
                      component="span"
                      variant="caption"
                      color="text.secondary"
                    >
                      {conversation.last_message && formatDate(conversation.last_message.created_at)}
                    </Typography>
                  </>
                }
              />
            </ListItem>
          );
        })
      )}
    </List>
  );
};

export default ConversationList;