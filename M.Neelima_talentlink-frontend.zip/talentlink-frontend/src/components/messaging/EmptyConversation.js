import React from 'react';
import { Box, Typography, Button } from '@mui/material';
import { Chat } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';

const EmptyConversation = () => {
  const navigate = useNavigate();

  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        height: '100%',
        p: 3
      }}
    >
      <Chat sx={{ fontSize: 80, color: 'text.secondary', mb: 2 }} />
      <Typography variant="h5" gutterBottom>
        No messages yet
      </Typography>
      <Typography variant="body1" color="text.secondary" align="center" sx={{ mb: 3 }}>
        Start a conversation by selecting a contract or wait for someone to message you.
      </Typography>
      <Button
        variant="contained"
        onClick={() => navigate('/contracts')}
      >
        View Contracts
      </Button>
    </Box>
  );
};

export default EmptyConversation;