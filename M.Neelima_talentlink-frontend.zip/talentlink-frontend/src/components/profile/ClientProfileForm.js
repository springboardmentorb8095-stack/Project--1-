import React, { useState, useEffect } from 'react';
import {
  Box, TextField, Button, Typography, Paper,
  FormControl, InputLabel, Select, MenuItem, Alert
} from '@mui/material';
import { useAuth } from '../../context/AuthContext';
import authService from '../../services/auth';

const ClientProfileForm = () => {
  const { user, updateUser } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [formData, setFormData] = useState({
    company_name: '',
    company_description: '',
    industry: '',
    company_size: '',
    website: '',
    location: ''
  });

  const companySizes = [
    '1-10 employees',
    '11-50 employees',
    '51-200 employees',
    '201-500 employees',
    '500+ employees'
  ];

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      setError('');
      const response = await authService.getProfile();
      console.log('Fetched profile response:', response);
      
      // Handle the nested structure
      if (response && response.profile) {
        const profile = response.profile;
        setFormData({
          company_name: profile.company_name || '',
          company_description: profile.company_description || '',
          industry: profile.industry || '',
          company_size: profile.company_size || '',
          website: profile.website || '',
          location: profile.location || ''
        });
      }
    } catch (error) {
      console.error('Error fetching profile:', error);
      setError('Failed to load profile data');
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');

    try {
      console.log('Submitting client profile data:', formData);
      
      const response = await authService.updateProfile(formData);
      console.log('Update response:', response);
      
      setSuccess('Profile updated successfully!');
      
      // Refresh the profile data to confirm the update
      setTimeout(() => {
        fetchProfile();
        setSuccess('');
      }, 2000);
      
    } catch (error) {
      console.error('Error updating profile:', error);
      setError(error.response?.data?.error || 'Failed to update profile');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Paper elevation={3} sx={{ p: 4 }}>
      <Typography variant="h5" gutterBottom>
        Company Profile
      </Typography>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
      {success && <Alert severity="success" sx={{ mb: 2 }}>{success}</Alert>}

      <Box component="form" onSubmit={handleSubmit} sx={{ mt: 3 }}>
        <TextField
          fullWidth
          label="Company Name"
          name="company_name"
          value={formData.company_name}
          onChange={handleChange}
          margin="normal"
          required
        />

        <TextField
          fullWidth
          label="Company Description"
          name="company_description"
          value={formData.company_description}
          onChange={handleChange}
          margin="normal"
          multiline
          rows={4}
          required
          placeholder="Tell us about your company..."
        />

        <TextField
          fullWidth
          label="Industry"
          name="industry"
          value={formData.industry}
          onChange={handleChange}
          margin="normal"
          required
          placeholder="e.g., Technology, Healthcare, Finance"
        />

        <FormControl fullWidth margin="normal">
          <InputLabel>Company Size</InputLabel>
          <Select
            name="company_size"
            value={formData.company_size}
            onChange={handleChange}
            label="Company Size"
            required
          >
            {companySizes.map((size) => (
              <MenuItem key={size} value={size}>
                {size}
              </MenuItem>
            ))}
          </Select>
        </FormControl>

        <TextField
          fullWidth
          label="Website"
          name="website"
          type="url"
          value={formData.website}
          onChange={handleChange}
          margin="normal"
          placeholder="https://your-company.com"
        />

        <TextField
          fullWidth
          label="Location"
          name="location"
          value={formData.location}
          onChange={handleChange}
          margin="normal"
          required
          placeholder="e.g., San Francisco, CA"
        />

        <Button
          type="submit"
          variant="contained"
          fullWidth
          sx={{ mt: 3 }}
          disabled={loading}
        >
          {loading ? 'Updating...' : 'Update Profile'}
        </Button>
      </Box>
    </Paper>
  );
};

export default ClientProfileForm;