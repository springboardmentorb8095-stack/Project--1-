import React, { useState, useEffect } from 'react';
import {
  Box, TextField, Button, Typography, Chip, Paper,
  InputAdornment, Alert
} from '@mui/material';
import { useAuth } from '../../context/AuthContext';
import authService from '../../services/auth';

import { useNavigate } from 'react-router-dom';
import RatingStars from '../reviews/RatingStars';

const FreelancerProfileForm = () => {
  const { user, updateUser } = useAuth();
  const navigate = useNavigate(); 
  const [loading, setLoading] = useState(false);
  const [skills, setSkills] = useState([]);
  const [newSkill, setNewSkill] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [formData, setFormData] = useState({
    title: '',
    bio: '',
    hourly_rate: '',
    years_of_experience: '',
    portfolio_url: '',
    availability: 'Available'
  });

  

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      setError('');
      const response = await authService.getProfile();
      console.log('Full profile response:', response);
      
      if (response && response.profile) {
        const profile = response.profile;
        console.log('Profile data:', profile);
        console.log('Skills from profile:', profile.skills);
        console.log('Skills type:', typeof profile.skills);
        
        setFormData({
          title: profile.title || '',
          bio: profile.bio || '',
          hourly_rate: profile.hourly_rate || '',
          years_of_experience: profile.years_of_experience || '',
          portfolio_url: profile.portfolio_url || '',
          availability: profile.availability || 'Available'
        });
        
        // Handle skills - ensure it's always an array
        let skillsArray = [];
        if (profile.skills) {
          if (Array.isArray(profile.skills)) {
            skillsArray = profile.skills;
          } else if (typeof profile.skills === 'string') {
            try {
              skillsArray = JSON.parse(profile.skills);
            } catch (e) {
              console.error('Failed to parse skills string:', e);
              skillsArray = [];
            }
          } else if (typeof profile.skills === 'object') {
            // If it's an object, try to convert it
            skillsArray = Object.values(profile.skills);
          }
        }
        
        console.log('Final skills array:', skillsArray);
        setSkills(skillsArray);
      }
    } catch (error) {
      console.error('Error fetching profile:', error);
      setError('Failed to load profile data');
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleAddSkill = (e) => {
    if (e.key === 'Enter' && newSkill.trim()) {
      e.preventDefault();
      if (!skills.includes(newSkill.trim())) {
        setSkills([...skills, newSkill.trim()]);
      }
      setNewSkill('');
    }
  };

  const handleDeleteSkill = (skillToDelete) => {
    setSkills(skills.filter(skill => skill !== skillToDelete));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');

    try {
      // Ensure skills is always sent as an array
      const profileData = {
        title: formData.title,
        bio: formData.bio,
        hourly_rate: parseFloat(formData.hourly_rate) || 0,
        years_of_experience: parseInt(formData.years_of_experience) || 0,
        portfolio_url: formData.portfolio_url || '',
        availability: formData.availability,
        skills: skills // This should already be an array
      };

      console.log('Submitting profile data:', profileData);
      console.log('Skills being submitted:', profileData.skills);
      
      const response = await authService.updateProfile(profileData);
      console.log('Update response:', response);
      
      setSuccess('Profile updated successfully!');
      
      // Refresh the profile data to confirm the update
      setTimeout(() => {
        fetchProfile();
        setSuccess('');
      }, 2000);
      
    } catch (error) {
      console.error('Error updating profile:', error);
      setError(error.response?.data?.error || 'Failed to update profile');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Paper elevation={3} sx={{ p: 4 }}>
      <Typography variant="h5" gutterBottom>
        Freelancer Profile
      </Typography>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
      {success && <Alert severity="success" sx={{ mb: 2 }}>{success}</Alert>}

      <Box component="form" onSubmit={handleSubmit} sx={{ mt: 3 }}>
        <TextField
          fullWidth
          label="Professional Title"
          name="title"
          value={formData.title}
          onChange={handleChange}
          margin="normal"
          required
          placeholder="e.g., Full Stack Developer"
        />

        <TextField
          fullWidth
          label="Bio"
          name="bio"
          value={formData.bio}
          onChange={handleChange}
          margin="normal"
          multiline
          rows={4}
          required
          placeholder="Tell us about your experience and expertise..."
        />

        <Box sx={{ mt: 2, mb: 2 }}>
          <TextField
            fullWidth
            label="Add Skills"
            value={newSkill}
            onChange={(e) => setNewSkill(e.target.value)}
            onKeyDown={handleAddSkill}
            placeholder="Type a skill and press Enter"
            margin="normal"
          />
          <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>
            Current skills: {skills.length}
          </Typography>
          <Box sx={{ mt: 1, display: 'flex', flexWrap: 'wrap', gap: 1 }}>
            {skills.length > 0 ? (
              skills.map((skill, index) => (
                <Chip
                  key={`${skill}-${index}`}
                  label={skill}
                  onDelete={() => handleDeleteSkill(skill)}
                  color="primary"
                />
              ))
            ) : (
              <Typography variant="body2" color="text.secondary">
                No skills added yet
              </Typography>
            )}
          </Box>
        </Box>

        <Box sx={{ display: 'flex', gap: 2 }}>
          <TextField
            fullWidth
            label="Hourly Rate"
            name="hourly_rate"
            type="number"
            value={formData.hourly_rate}
            onChange={handleChange}
            margin="normal"
            required
            InputProps={{
              startAdornment: <InputAdornment position="start">$</InputAdornment>,
            }}
          />

          <TextField
            fullWidth
            label="Years of Experience"
            name="years_of_experience"
            type="number"
            value={formData.years_of_experience}
            onChange={handleChange}
            margin="normal"
            required
          />
        </Box>

        <TextField
          fullWidth
          label="Portfolio URL"
          name="portfolio_url"
          type="url"
          value={formData.portfolio_url}
          onChange={handleChange}
          margin="normal"
          placeholder="https://your-portfolio.com"

        />

        {/* Rating Display */}
        {user && (
          <Box sx={{ mb: 3, display: 'flex', alignItems: 'center', gap: 2 }}>
            <RatingStars value={user.average_rating || 0} readOnly />
            <Typography variant="body2" color="text.secondary">
              ({user.total_reviews || 0} reviews)
            </Typography>
            <Button 
              size="small" 
              onClick={() => navigate(`/reviews/user/${user.id}`)}
            >
              View All Reviews
            </Button>
          </Box>
        )}

        <Button
          type="submit"
          variant="contained"
          fullWidth
          sx={{ mt: 3 }}
          disabled={loading}
        >
          {loading ? 'Updating...' : 'Update Profile'}
        </Button>
      </Box>
    </Paper>
  );
};

export default FreelancerProfileForm;