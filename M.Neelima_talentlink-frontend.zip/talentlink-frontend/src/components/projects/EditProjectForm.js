import React, { useState, useEffect } from 'react';
import {
  Box, TextField, Button, Typography, Paper, Chip,
  FormControl, InputLabel, Select, MenuItem, InputAdornment, Alert
} from '@mui/material';
import { DateTimePicker } from '@mui/x-date-pickers/DateTimePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import projectService from '../../services/projects';
import { useNavigate, useParams } from 'react-router-dom';
import LoadingSpinner from '../common/LoadingSpinner';

const EditProjectForm = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [skills, setSkills] = useState([]);
  const [newSkill, setNewSkill] = useState('');
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    budget_type: 'FIXED',
    budget_amount: '',
    duration_in_days: '',
    deadline: new Date(),
    status: 'OPEN'
  });

  useEffect(() => {
    fetchProject();
  }, [id]);

  const fetchProject = async () => {
    try {
      const project = await projectService.getProject(id);
      
      // Check if user is the owner
      const currentUser = JSON.parse(localStorage.getItem('user'));
      if (project.client.id !== currentUser.id) {
        setError('You are not authorized to edit this project');
        return;
      }

      setFormData({
        title: project.title,
        description: project.description,
        budget_type: project.budget_type,
        budget_amount: project.budget_amount,
        duration_in_days: project.duration_in_days,
        deadline: new Date(project.deadline),
        status: project.status
      });
      setSkills(project.required_skills || []);
    } catch (error) {
      console.error('Error fetching project:', error);
      setError('Failed to load project');
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleAddSkill = (e) => {
    if (e.key === 'Enter' && newSkill.trim()) {
      e.preventDefault();
      if (!skills.includes(newSkill.trim())) {
        setSkills([...skills, newSkill.trim()]);
      }
      setNewSkill('');
    }
  };

  const handleDeleteSkill = (skillToDelete) => {
    setSkills(skills.filter(skill => skill !== skillToDelete));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    
    if (skills.length === 0) {
      setError('Please add at least one required skill');
      return;
    }

    setSaving(true);

    try {
      const projectData = {
        title: formData.title,
        description: formData.description,
        budget_type: formData.budget_type,
        budget_amount: parseFloat(formData.budget_amount),
        duration_in_days: parseInt(formData.duration_in_days),
        deadline: formData.deadline.toISOString(),
        required_skills: skills,
        status: formData.status
      };

      console.log('Updating project with data:', projectData);

      await projectService.updateProject(id, projectData);
      navigate(`/projects/${id}`);
    } catch (error) {
      console.error('Error updating project:', error);
      setError(error.response?.data?.detail || 'Failed to update project');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (window.confirm('Are you sure you want to delete this project? This action cannot be undone.')) {
      try {
        await projectService.deleteProject(id);
        navigate('/projects/my');
      } catch (error) {
        console.error('Error deleting project:', error);
        setError('Failed to delete project');
      }
    }
  };

  if (loading) return <LoadingSpinner />;

  if (error && !formData.title) {
    return (
      <Paper elevation={3} sx={{ p: 4 }}>
        <Alert severity="error">{error}</Alert>
      </Paper>
    );
  }

  return (
    <Paper elevation={3} sx={{ p: 4 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h5">
          Edit Project
        </Typography>
        <Button 
          variant="outlined" 
          color="error"
          onClick={handleDelete}
          disabled={formData.status !== 'OPEN'}
        >
          Delete Project
        </Button>
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}

      {formData.status !== 'OPEN' && (
        <Alert severity="warning" sx={{ mb: 2 }}>
          This project is {formData.status.toLowerCase()} and has limited editing capabilities.
        </Alert>
      )}

      <Box component="form" onSubmit={handleSubmit} sx={{ mt: 3 }}>
        <TextField
          fullWidth
          label="Project Title"
          name="title"
          value={formData.title}
          onChange={handleChange}
          margin="normal"
          required
          disabled={formData.status !== 'OPEN'}
        />

        <TextField
          fullWidth
          label="Project Description"
          name="description"
          value={formData.description}
          onChange={handleChange}
          margin="normal"
          multiline
          rows={6}
          required
        />

        <Box sx={{ mt: 2, mb: 2 }}>
          <TextField
            fullWidth
            label="Required Skills"
            value={newSkill}
            onChange={(e) => setNewSkill(e.target.value)}
            onKeyDown={handleAddSkill}
            placeholder="Type a skill and press Enter"
            margin="normal"
            disabled={formData.status !== 'OPEN'}
          />
          <Box sx={{ mt: 1, display: 'flex', flexWrap: 'wrap', gap: 1 }}>
            {skills.map((skill, index) => (
              <Chip
                key={index}
                label={skill}
                onDelete={formData.status === 'OPEN' ? () => handleDeleteSkill(skill) : undefined}
                color="primary"
              />
            ))}
          </Box>
          {skills.length === 0 && (
            <Typography variant="caption" color="error">
              * Add at least one required skill
            </Typography>
          )}
        </Box>

        <Box sx={{ display: 'flex', gap: 2 }}>
          <FormControl fullWidth margin="normal">
            <InputLabel>Budget Type</InputLabel>
            <Select
              name="budget_type"
              value={formData.budget_type}
              onChange={handleChange}
              label="Budget Type"
              disabled={formData.status !== 'OPEN'}
            >
              <MenuItem value="FIXED">Fixed Price</MenuItem>
              <MenuItem value="HOURLY">Hourly Rate</MenuItem>
            </Select>
          </FormControl>

          <TextField
            fullWidth
            label={formData.budget_type === 'FIXED' ? 'Budget Amount' : 'Hourly Rate'}
            name="budget_amount"
            type="number"
            value={formData.budget_amount}
            onChange={handleChange}
            margin="normal"
            required
            disabled={formData.status !== 'OPEN'}
            InputProps={{
              startAdornment: <InputAdornment position="start">$</InputAdornment>,
            }}
          />
        </Box>

        <Box sx={{ display: 'flex', gap: 2, alignItems: 'center' }}>
          <TextField
            fullWidth
            label="Duration (in days)"
            name="duration_in_days"
            type="number"
            value={formData.duration_in_days}
            onChange={handleChange}
            margin="normal"
            required
          />

          <Box sx={{ width: '100%', mt: 2 }}>
            <LocalizationProvider dateAdapter={AdapterDateFns}>
              <DateTimePicker
                label="Deadline"
                value={formData.deadline}
                onChange={(newValue) => setFormData({ ...formData, deadline: newValue })}
                minDate={new Date()}
                slotProps={{
                  textField: {
                    fullWidth: true,
                    required: true,
                  },
                }}
              />
            </LocalizationProvider>
          </Box>
        </Box>

        {formData.status === 'OPEN' && (
          <FormControl fullWidth margin="normal">
            <InputLabel>Status</InputLabel>
            <Select
              name="status"
              value={formData.status}
              onChange={handleChange}
              label="Status"
            >
              <MenuItem value="OPEN">Open</MenuItem>
              <MenuItem value="CANCELLED">Cancelled</MenuItem>
            </Select>
          </FormControl>
        )}

        <Box sx={{ display: 'flex', gap: 2, mt: 3 }}>
          <Button
            type="submit"
            variant="contained"
            fullWidth
            disabled={saving || skills.length === 0}
          >
            {saving ? 'Updating...' : 'Update Project'}
          </Button>
          <Button
            variant="outlined"
            fullWidth
            onClick={() => navigate(`/projects/${id}`)}
          >
            Cancel
          </Button>
        </Box>
      </Box>
    </Paper>
  );
};

export default EditProjectForm;