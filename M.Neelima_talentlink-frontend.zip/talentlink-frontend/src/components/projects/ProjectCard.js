import React from 'react';
import {
  Card, CardContent, CardActions, Typography, Chip, Box, Button
} from '@mui/material';
import { AccessTime, AttachMoney, Work } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { formatCurrency, formatDate } from '../../services/utils';
import RatingStars from '../reviews/RatingStars';
const ProjectCard = ({ project }) => {
  const navigate = useNavigate();

  const getStatusColor = (status) => {
    const colors = {
      'OPEN': 'success',
      'IN_PROGRESS': 'warning',
      'COMPLETED': 'default',
      'CANCELLED': 'error'
    };
    return colors[status] || 'default';
  };

  return (
    <Card elevation={2} sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      <CardContent sx={{ flexGrow: 1 }}>
        <Typography variant="h6" gutterBottom>
          {project.title}
        </Typography>
        
        <Chip 
          label={project.status} 
          color={getStatusColor(project.status)}
          size="small"
          sx={{ mb: 2 }}
        />

        <Typography variant="body2" color="text.secondary" paragraph>
          {project.description.substring(0, 150)}...
        </Typography>

        <Box sx={{ mb: 2 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
            <AttachMoney sx={{ mr: 1, fontSize: 20 }} />
            <Typography variant="body2">
              {project.budget_type === 'FIXED' ? 
                `Fixed: ${formatCurrency(project.budget_amount)}` : 
                `Hourly: ${formatCurrency(project.budget_amount)}/hr`
              }
            </Typography>
          </Box>

          <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
            <AccessTime sx={{ mr: 1, fontSize: 20 }} />
            <Typography variant="body2">
              Duration: {project.duration_in_days} days
            </Typography>
          </Box>

          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <Work sx={{ mr: 1, fontSize: 20 }} />
            <Typography variant="body2">
              {project.proposals_count || 0} proposals
            </Typography>
          </Box>
        </Box>

        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
          {project.required_skills.map((skill, index) => (
            <Chip 
              key={index} 
              label={skill} 
              size="small" 
              variant="outlined"
            />
          ))}
        </Box>

        <Typography variant="caption" display="block" sx={{ mt: 2 }}>
          Posted on {formatDate(project.created_at)}
        </Typography>
      </CardContent>

          {project.client.average_rating > 0 && (
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mt: 0.5 }}>
          <RatingStars value={project.client.average_rating} readOnly size="small" />
          <Typography variant="caption" color="text.secondary">
            ({project.client.total_reviews} reviews)
          </Typography>
        </Box>
      )}

      <CardActions>
        <Button 
          size="small" 
          variant="contained"
          onClick={() => navigate(`/projects/${project.id}`)}
          fullWidth
        >
          View Details
        </Button>
      </CardActions>
    </Card>
  );
};

export default ProjectCard;