import React, { useState } from 'react';
import {
  Box, TextField, Button, Typography, Paper, Chip,
  FormControl, InputLabel, Select, MenuItem, InputAdornment, Alert
} from '@mui/material';
import { DateTimePicker } from '@mui/x-date-pickers/DateTimePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import projectService from '../../services/projects';
import { useNavigate } from 'react-router-dom';

const CreateProjectForm = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [skills, setSkills] = useState([]);
  const [newSkill, setNewSkill] = useState('');
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    budget_type: 'FIXED',
    budget_amount: '',
    duration_in_days: '',
    deadline: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleAddSkill = (e) => {
    if (e.key === 'Enter' && newSkill.trim()) {
      e.preventDefault();
      if (!skills.includes(newSkill.trim())) {
        setSkills([...skills, newSkill.trim()]);
      }
      setNewSkill('');
    }
  };

  const handleDeleteSkill = (skillToDelete) => {
    setSkills(skills.filter(skill => skill !== skillToDelete));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    
    // Validate skills
    if (skills.length === 0) {
      setError('Please add at least one required skill');
      return;
    }

    setLoading(true);

    try {
      const projectData = {
        title: formData.title,
        description: formData.description,
        budget_type: formData.budget_type,
        budget_amount: parseFloat(formData.budget_amount),
        duration_in_days: parseInt(formData.duration_in_days),
        deadline: formData.deadline.toISOString(),
        required_skills: skills,
        status: 'OPEN'
      };

      console.log('Sending project data:', projectData);

      const response = await projectService.createProject(projectData);
      console.log('Project created successfully:', response);
      
      navigate(`/projects/${response.id}`);
    } catch (error) {
      console.error('Error creating project:', error);
      console.error('Error response:', error.response?.data);
      setError(error.response?.data?.detail || 'Failed to create project');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Paper elevation={3} sx={{ p: 4 }}>
      <Typography variant="h5" gutterBottom>
        Create New Project
      </Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}

      <Box component="form" onSubmit={handleSubmit} sx={{ mt: 3 }}>
        <TextField
          fullWidth
          label="Project Title"
          name="title"
          value={formData.title}
          onChange={handleChange}
          margin="normal"
          required
        />

        <TextField
          fullWidth
          label="Project Description"
          name="description"
          value={formData.description}
          onChange={handleChange}
          margin="normal"
          multiline
          rows={6}
          required
          placeholder="Describe your project requirements, deliverables, and expectations..."
        />

        <Box sx={{ mt: 2, mb: 2 }}>
          <TextField
            fullWidth
            label="Required Skills"
            value={newSkill}
            onChange={(e) => setNewSkill(e.target.value)}
            onKeyDown={handleAddSkill}
            placeholder="Type a skill and press Enter"
            margin="normal"
          />
          <Box sx={{ mt: 1, display: 'flex', flexWrap: 'wrap', gap: 1 }}>
            {skills.map((skill, index) => (
              <Chip
                key={index}
                label={skill}
                onDelete={() => handleDeleteSkill(skill)}
                color="primary"
              />
            ))}
          </Box>
          {skills.length === 0 && (
            <Typography variant="caption" color="error">
              * Add at least one required skill
            </Typography>
          )}
        </Box>

        <Box sx={{ display: 'flex', gap: 2 }}>
          <FormControl fullWidth margin="normal">
            <InputLabel>Budget Type</InputLabel>
            <Select
              name="budget_type"
              value={formData.budget_type}
              onChange={handleChange}
              label="Budget Type"
            >
              <MenuItem value="FIXED">Fixed Price</MenuItem>
              <MenuItem value="HOURLY">Hourly Rate</MenuItem>
            </Select>
          </FormControl>

          <TextField
            fullWidth
            label={formData.budget_type === 'FIXED' ? 'Budget Amount' : 'Hourly Rate'}
            name="budget_amount"
            type="number"
            value={formData.budget_amount}
            onChange={handleChange}
            margin="normal"
            required
            InputProps={{
              startAdornment: <InputAdornment position="start">$</InputAdornment>,
            }}
          />
        </Box>

        <Box sx={{ display: 'flex', gap: 2, alignItems: 'center' }}>
          <TextField
            fullWidth
            label="Duration (in days)"
            name="duration_in_days"
            type="number"
            value={formData.duration_in_days}
            onChange={handleChange}
            margin="normal"
            required
          />

          <Box sx={{ width: '100%', mt: 2 }}>
            <LocalizationProvider dateAdapter={AdapterDateFns}>
              <DateTimePicker
                label="Deadline"
                value={formData.deadline}
                onChange={(newValue) => setFormData({ ...formData, deadline: newValue })}
                minDate={new Date()}
                slotProps={{
                  textField: {
                    fullWidth: true,
                    required: true,
                  },
                }}
              />
            </LocalizationProvider>
          </Box>
        </Box>

        <Button
          type="submit"
          variant="contained"
          fullWidth
          sx={{ mt: 3 }}
          disabled={loading || skills.length === 0}
        >
          {loading ? 'Creating...' : 'Create Project'}
        </Button>
      </Box>
    </Paper>
  );
};

export default CreateProjectForm;