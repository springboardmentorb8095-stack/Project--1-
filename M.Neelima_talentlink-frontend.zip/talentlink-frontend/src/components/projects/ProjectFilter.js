import React from 'react';
import {
  Box, TextField, FormControl, InputLabel, Select, MenuItem,
  Slider, Typography, Button, Paper
} from '@mui/material';

const ProjectFilter = ({ filters, onFilterChange, onApplyFilters, onClearFilters }) => {
  const handleChange = (field, value) => {
    onFilterChange({ ...filters, [field]: value });
  };

  return (
    <Paper elevation={1} sx={{ p: 3 }}>
      <Typography variant="h6" gutterBottom>
        Filter Projects
      </Typography>

      <TextField
        fullWidth
        label="Search Keywords"
        value={filters.search || ''}
        onChange={(e) => handleChange('search', e.target.value)}
        margin="normal"
        placeholder="Search in title and description..."
      />

      <TextField
        fullWidth
        label="Required Skills"
        value={filters.skills || ''}
        onChange={(e) => handleChange('skills', e.target.value)}
        margin="normal"
        placeholder="e.g., Python, React, Django"
        helperText="Comma separated skills"
      />

      <FormControl fullWidth margin="normal">
        <InputLabel>Budget Type</InputLabel>
        <Select
          value={filters.budget_type || ''}
          onChange={(e) => handleChange('budget_type', e.target.value)}
          label="Budget Type"
        >
          <MenuItem value="">All</MenuItem>
          <MenuItem value="FIXED">Fixed Price</MenuItem>
          <MenuItem value="HOURLY">Hourly Rate</MenuItem>
        </Select>
      </FormControl>

      <FormControl fullWidth margin="normal">
        <InputLabel>Status</InputLabel>
        <Select
          value={filters.status || ''}
          onChange={(e) => handleChange('status', e.target.value)}
          label="Status"
        >
          <MenuItem value="">All</MenuItem>
          <MenuItem value="OPEN">Open</MenuItem>
          <MenuItem value="IN_PROGRESS">In Progress</MenuItem>
          <MenuItem value="COMPLETED">Completed</MenuItem>
        </Select>
      </FormControl>

      <Box sx={{ mt: 3, mb: 2 }}>
        <Typography gutterBottom>Budget Range</Typography>
        <Box sx={{ display: 'flex', gap: 2, mb: 1 }}>
          <TextField
            type="number"
            label="Min Budget"
            value={filters.min_budget || ''}
            onChange={(e) => handleChange('min_budget', e.target.value)}
            size="small"
          />
          <TextField
            type="number"
            label="Max Budget"
            value={filters.max_budget || ''}
            onChange={(e) => handleChange('max_budget', e.target.value)}
            size="small"
          />
        </Box>
      </Box>

      <Box sx={{ display: 'flex', gap: 2, mt: 3 }}>
        <Button 
          variant="contained" 
          onClick={onApplyFilters}
                    fullWidth
        >
          Apply Filters
        </Button>
        <Button 
          variant="outlined" 
          onClick={onClearFilters}
          fullWidth
        >
          Clear
        </Button>
      </Box>
    </Paper>
  );
};

export default ProjectFilter;