import React from 'react';
import {
  Card, CardContent, CardActions, Box, Typography, 
  Chip, Button, LinearProgress, Avatar, Stack
} from '@mui/material';
import {
  AccessTime, AttachMoney, Person, CalendarToday, Chat
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { formatCurrency, formatDate } from '../../services/utils';

const ContractCard = ({ contract }) => {
  const navigate = useNavigate();

  const getStatusColor = (status) => {
    const colors = {
      'ACTIVE': 'success',
      'Active': 'success',
      'COMPLETED': 'default',
      'Completed': 'default',
      'TERMINATED': 'error',
      'DISPUTED': 'warning'
    };
    return colors[status] || 'default';
  };

  // Calculate progress
  const calculateProgress = () => {
    if (contract.status !== 'ACTIVE' && contract.status !== 'Active') return 100;
    
    const start = new Date(contract.start_date);
    const end = new Date(contract.end_date);
    const now = new Date();
    
    const total = end - start;
    const elapsed = now - start;
    const progress = (elapsed / total) * 100;
    
    return Math.min(Math.max(progress, 0), 100);
  };

  const progress = calculateProgress();
  const daysRemaining = Math.ceil((new Date(contract.end_date) - new Date()) / (1000 * 60 * 60 * 24));

  return (
    <Card elevation={2} sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      <CardContent sx={{ flexGrow: 1 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', mb: 2 }}>
          <Typography variant="h6" gutterBottom>
            {contract.project?.title || 'Project'}
          </Typography>
          <Chip 
            label={contract.status} 
            color={getStatusColor(contract.status)}
            size="small"
          />
        </Box>

        <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
          <Person sx={{ mr: 1, fontSize: 20 }} />
          <Typography variant="body2" color="text.secondary">
            {contract.client?.id === JSON.parse(localStorage.getItem('user'))?.id 
              ? `${contract.freelancer?.first_name} ${contract.freelancer?.last_name}`
              : `${contract.client?.first_name} ${contract.client?.last_name}`
            }
          </Typography>
        </Box>

        <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
          <AttachMoney sx={{ mr: 1, fontSize: 20 }} />
          <Typography variant="body2">
            Total: {formatCurrency(contract.total_amount)}
          </Typography>
        </Box>

        <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
          <CalendarToday sx={{ mr: 1, fontSize: 20 }} />
          <Typography variant="body2">
            {formatDate(contract.start_date)} - {formatDate(contract.end_date)}
          </Typography>
        </Box>

        {(contract.status === 'ACTIVE' || contract.status === 'Active') && (
          <Box sx={{ mb: 2 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
              <Typography variant="body2">Progress</Typography>
              <Typography variant="body2">{Math.round(progress)}%</Typography>
            </Box>
            <LinearProgress 
              variant="determinate" 
              value={progress} 
              sx={{ height: 8, borderRadius: 4 }}
            />
            <Typography variant="caption" color="text.secondary" sx={{ mt: 0.5 }}>
              {daysRemaining > 0 ? `${daysRemaining} days remaining` : 'Overdue'}
            </Typography>
          </Box>
        )}
      </CardContent>

      <CardActions sx={{ p: 2 }}>
        <Stack direction="row" spacing={1} sx={{ width: '100%' }}>
          <Button 
            size="small" 
            variant="contained"
            onClick={() => navigate(`/contracts/${contract.id}`)}
            fullWidth
          >
            View Details
          </Button>
          {(contract.status === 'ACTIVE' || contract.status === 'Active') && (
            <Button 
              size="small" 
              variant="outlined"
              startIcon={<Chat />}
              onClick={() => navigate(`/messages?contract_id=${contract.id}`)}
              fullWidth
            >
              Message
            </Button>
          )}
        </Stack>
      </CardActions>
    </Card>
  );
};

export default ContractCard;