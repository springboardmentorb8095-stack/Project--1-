import React from 'react';
import { Box, Paper, Typography, Grid } from '@mui/material';
import { formatCurrency } from '../../services/utils';

const ContractStats = ({ stats }) => {
  return (
    <Paper elevation={2} sx={{ p: 3, mb: 3 }}>
      <Typography variant="h6" gutterBottom>
        Contract Overview
      </Typography>
      
      <Grid container spacing={3}>
        <Grid item xs={6} md={3}>
          <Typography variant="body2" color="text.secondary">
            Total Contracts
          </Typography>
          <Typography variant="h4">
            {stats.total}
          </Typography>
        </Grid>
        
        <Grid item xs={6} md={3}>
          <Typography variant="body2" color="text.secondary">
            Active
          </Typography>
          <Typography variant="h4" color="success.main">
            {stats.active}
          </Typography>
        </Grid>
        
        <Grid item xs={6} md={3}>
          <Typography variant="body2" color="text.secondary">
            Completed
          </Typography>
          <Typography variant="h4">
            {stats.completed}
          </Typography>
        </Grid>
        
        <Grid item xs={6} md={3}>
          <Typography variant="body2" color="text.secondary">
            Total Value
          </Typography>
          <Typography variant="h5">
            {formatCurrency(stats.totalValue)}
          </Typography>
        </Grid>
      </Grid>
    </Paper>
  );
};

export default ContractStats;