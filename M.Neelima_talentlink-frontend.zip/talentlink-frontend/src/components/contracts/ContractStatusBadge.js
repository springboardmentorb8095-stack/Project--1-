import React from 'react';
import { Chip } from '@mui/material';
import {
  CheckCircle, Cancel, Warning, HourglassEmpty
} from '@mui/icons-material';

const ContractStatusBadge = ({ status, size = 'medium' }) => {
  const getStatusConfig = (status) => {
    const configs = {
      'ACTIVE': {
        color: 'success',
        icon: <HourglassEmpty />,
        label: 'Active'
      },
      'Active': {
        color: 'success',
        icon: <HourglassEmpty />,
        label: 'Active'
      },
      'COMPLETED': {
        color: 'default',
        icon: <CheckCircle />,
        label: 'Completed'
      },
      'Completed': {
        color: 'default',
        icon: <CheckCircle />,
        label: 'Completed'
      },
      'TERMINATED': {
        color: 'error',
        icon: <Cancel />,
        label: 'Terminated'
      },
      'DISPUTED': {
        color: 'warning',
        icon: <Warning />,
        label: 'Disputed'
      }
    };
    return configs[status] || { color: 'default', label: status };
  };

  const config = getStatusConfig(status);

  return (
    <Chip
      label={config.label}
      color={config.color}
      size={size}
      icon={config.icon}
    />
  );
};

export default ContractStatusBadge;