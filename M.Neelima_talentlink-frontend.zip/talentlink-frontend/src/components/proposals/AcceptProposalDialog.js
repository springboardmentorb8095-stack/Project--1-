import React, { useState } from 'react';
import {
  Dialog, DialogTitle, DialogContent, DialogActions,
  Button, TextField, Box, Typography
} from '@mui/material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';

const AcceptProposalDialog = ({ open, onClose, onConfirm, proposal }) => {
  const [contractData, setContractData] = useState({
    start_date: new Date(),
    end_date: new Date(Date.now() + proposal?.estimated_duration * 24 * 60 * 60 * 1000),
    terms: 'Standard terms apply. Payment will be made upon successful completion of the project.'
  });

  const handleSubmit = () => {
    onConfirm({
      ...contractData,
      start_date: contractData.start_date.toISOString(),
      end_date: contractData.end_date.toISOString()
    });
  };

  if (!proposal) return null;

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>Accept Proposal & Create Contract</DialogTitle>
      <DialogContent>
        <Box sx={{ mt: 2 }}>
          <Typography variant="body2" gutterBottom>
            You are about to accept the proposal from {proposal.freelancer.first_name} {proposal.freelancer.last_name}
          </Typography>
          
          <LocalizationProvider dateAdapter={AdapterDateFns}>
            <Box sx={{ display: 'flex', gap: 2, mt: 3 }}>
              <DatePicker
                label="Start Date"
                value={contractData.start_date}
                onChange={(newValue) => 
                  setContractData({ ...contractData, start_date: newValue })
                }
                slotProps={{
                  textField: {
                    fullWidth: true,
                  },
                }}
              />
              <DatePicker
                label="End Date"
                value={contractData.end_date}
                                onChange={(newValue) => 
                  setContractData({ ...contractData, end_date: newValue })
                }
                minDate={contractData.start_date}
                slotProps={{
                  textField: {
                    fullWidth: true,
                  },
                }}
              />
            </Box>
          </LocalizationProvider>

          <TextField
            fullWidth
            label="Contract Terms"
            value={contractData.terms}
            onChange={(e) => 
              setContractData({ ...contractData, terms: e.target.value })
            }
            multiline
            rows={4}
            margin="normal"
          />
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button onClick={handleSubmit} variant="contained" color="success">
          Accept & Create Contract
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default AcceptProposalDialog;