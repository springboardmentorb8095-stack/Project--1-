import React, { useState, useEffect } from 'react';
import {
  Box, TextField, Button, Typography, Paper, Alert,
  InputAdornment, Divider
} from '@mui/material';
import { useNavigate, useParams } from 'react-router-dom';
import projectService from '../../services/projects';
import proposalService from '../../services/proposals';
import LoadingSpinner from '../common/LoadingSpinner';
import { formatCurrency } from '../../services/utils';

const SubmitProposalForm = () => {
  const navigate = useNavigate();
  const { projectId } = useParams();
  const [project, setProject] = useState(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({
    cover_letter: '',
    proposed_rate: '',
    estimated_duration: ''
  });

  useEffect(() => {
    fetchProject();
  }, [projectId]);

  const fetchProject = async () => {
    try {
      const data = await projectService.getProject(projectId);
      setProject(data);
      
      // Set initial rate based on project budget
      setFormData(prev => ({
        ...prev,
        proposed_rate: data.budget_amount || '',
        estimated_duration: data.duration_in_days || ''
      }));
    } catch (error) {
      console.error('Error fetching project:', error);
      setError('Failed to load project details');
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSubmitting(true);

    try {
      const proposalData = {
        project: projectId,
        cover_letter: formData.cover_letter,
        proposed_rate: parseFloat(formData.proposed_rate),
        estimated_duration: parseInt(formData.estimated_duration)
      };

      await proposalService.submitProposal(proposalData);
      navigate(`/projects/${projectId}`, { 
        state: { message: 'Proposal submitted successfully!' }
      });
    } catch (error) {
      console.error('Error submitting proposal:', error);
      if (error.response?.data?.non_field_errors) {
        setError(error.response.data.non_field_errors[0]);
      } else {
        setError('Failed to submit proposal. Please try again.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) return <LoadingSpinner />;

  if (!project) {
    return (
      <Paper elevation={3} sx={{ p: 4 }}>
        <Alert severity="error">Project not found</Alert>
      </Paper>
    );
  }

  if (project.status !== 'OPEN') {
    return (
      <Paper elevation={3} sx={{ p: 4 }}>
        <Alert severity="warning">This project is no longer accepting proposals</Alert>
      </Paper>
    );
  }

  const totalProposedAmount = formData.proposed_rate && formData.estimated_duration
    ? parseFloat(formData.proposed_rate) * parseInt(formData.estimated_duration)
    : 0;

  return (
    <Paper elevation={3} sx={{ p: 4 }}>
      <Typography variant="h5" gutterBottom>
        Submit Proposal
      </Typography>

      <Box sx={{ mb: 3 }}>
        <Typography variant="h6" gutterBottom>
          {project.title}
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Budget: {project.budget_type === 'FIXED' 
            ? formatCurrency(project.budget_amount)
            : `${formatCurrency(project.budget_amount)}/hr`
          } • Duration: {project.duration_in_days} days
        </Typography>
      </Box>

      <Divider sx={{ mb: 3 }} />

      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}

      <Box component="form" onSubmit={handleSubmit}>
        <TextField
          fullWidth
          label="Cover Letter"
          name="cover_letter"
          value={formData.cover_letter}
          onChange={handleChange}
          margin="normal"
          multiline
          rows={8}
          required
          placeholder="Explain why you're the best fit for this project..."
          helperText="Describe your relevant experience and how you plan to complete this project"
        />

        <Box sx={{ display: 'flex', gap: 2, mt: 2 }}>
          <TextField
            fullWidth
            label={project.budget_type === 'FIXED' ? 'Your Bid Amount' : 'Hourly Rate'}
            name="proposed_rate"
            type="number"
            value={formData.proposed_rate}
            onChange={handleChange}
            margin="normal"
            required
            InputProps={{
              startAdornment: <InputAdornment position="start">$</InputAdornment>,
            }}
            helperText={`Project budget: ${formatCurrency(project.budget_amount)}`}
          />

          <TextField
            fullWidth
            label="Estimated Duration (days)"
            name="estimated_duration"
            type="number"
            value={formData.estimated_duration}
            onChange={handleChange}
            margin="normal"
            required
            helperText={`Project duration: ${project.duration_in_days} days`}
          />
        </Box>

        {project.budget_type === 'FIXED' && totalProposedAmount > 0 && (
          <Box sx={{ mt: 2, p: 2, bgcolor: 'grey.100', borderRadius: 1 }}>
            <Typography variant="subtitle1">
              Total Proposed Amount: <strong>{formatCurrency(totalProposedAmount)}</strong>
            </Typography>
          </Box>
        )}

        <Box sx={{ display: 'flex', gap: 2, mt: 3 }}>
          <Button
            type="submit"
            variant="contained"
            fullWidth
            disabled={submitting}
          >
            {submitting ? 'Submitting...' : 'Submit Proposal'}
          </Button>
          <Button
            variant="outlined"
            fullWidth
            onClick={() => navigate(`/projects/${projectId}`)}
          >
            Cancel
          </Button>
        </Box>
      </Box>
    </Paper>
  );
};

export default SubmitProposalForm;