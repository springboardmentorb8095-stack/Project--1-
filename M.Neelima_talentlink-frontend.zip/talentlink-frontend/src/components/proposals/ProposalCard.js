import React from 'react';
import {
  Card, CardContent, Box, Typography, Chip, Button, Avatar
} from '@mui/material';
import { Person, AccessTime, AttachMoney } from '@mui/icons-material';
import { formatCurrency, formatDate } from '../../services/utils';

const ProposalCard = ({ proposal, onAccept, onReject, isClient }) => {
  const getStatusColor = (status) => {
    const colors = {
      'PENDING': 'warning',
      'ACCEPTED': 'success',
      'REJECTED': 'error',
      'WITHDRAWN': 'default'
    };
    return colors[status] || 'default';
  };

  return (
    <Card elevation={2} sx={{ mb: 2 }}>
      <CardContent>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', mb: 2 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
            <Avatar>
              <Person />
            </Avatar>
            <Box>
              <Typography variant="h6">
                {proposal.freelancer.first_name} {proposal.freelancer.last_name}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                @{proposal.freelancer.username}
              </Typography>
            </Box>
          </Box>
          <Chip
            label={proposal.status}
            color={getStatusColor(proposal.status)}
            size="small"
          />
        </Box>

        {!isClient && proposal.project && (
          <Typography variant="subtitle1" gutterBottom>
            Project: {proposal.project.title}
          </Typography>
        )}

        <Typography variant="body2" paragraph sx={{ mt: 2 }}>
          {proposal.cover_letter}
        </Typography>

        <Box sx={{ display: 'flex', gap: 3, mt: 2 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
            <AttachMoney fontSize="small" />
            <Typography variant="body2">
              {formatCurrency(proposal.proposed_rate)}
              {proposal.project?.budget_type === 'HOURLY' && '/hr'}
            </Typography>
          </Box>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
            <AccessTime fontSize="small" />
            <Typography variant="body2">
              {proposal.estimated_duration} days
            </Typography>
          </Box>
        </Box>

        <Typography variant="caption" color="text.secondary" display="block" sx={{ mt: 2 }}>
          Submitted on {formatDate(proposal.created_at)}
        </Typography>

        {isClient && proposal.status === 'PENDING' && (
          <Box sx={{ display: 'flex', gap: 2, mt: 2 }}>
            <Button
              variant="contained"
              color="success"
              size="small"
              onClick={() => onAccept(proposal)}
            >
              Accept
            </Button>
            <Button
              variant="outlined"
              color="error"
              size="small"
              onClick={() => onReject(proposal)}
            >
              Reject
            </Button>
          </Box>
        )}
      </CardContent>
    </Card>
  );
};

export default ProposalCard;