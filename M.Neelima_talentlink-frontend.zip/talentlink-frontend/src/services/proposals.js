import api from './api';

const proposalService = {
  // Get all proposals (filtered by user type)
  async getProposals(params = {}) {
    const response = await api.get('/proposals/', { params });
    return response.data;
  },

  // Get single proposal
  async getProposal(id) {
    const response = await api.get(`/proposals/${id}/`);
    return response.data;
  },

  // Submit proposal (Freelancer only)
  async submitProposal(proposalData) {
    console.log('Submitting proposal:', proposalData);
    const response = await api.post('/proposals/', proposalData);
    return response.data;
  },

  // Update proposal
  async updateProposal(id, proposalData) {
    const response = await api.patch(`/proposals/${id}/`, proposalData);
    return response.data;
  },

  // Withdraw proposal
  async withdrawProposal(id) {
    const response = await api.patch(`/proposals/${id}/`, { status: 'WITHDRAWN' });
    return response.data;
  },

  // Accept proposal (Client only)
  async acceptProposal(id, contractData) {
    const response = await api.post(`/proposals/${id}/accept/`, contractData);
    return response.data;
  },

  // Reject proposal (Client only)
  async rejectProposal(id) {
    const response = await api.post(`/proposals/${id}/reject/`);
    return response.data;
  },

  // Get proposals for a specific project
  async getProjectProposals(projectId) {
    const response = await api.get('/proposals/', { 
      params: { project: projectId } 
    });
    return response.data;
  }
};

export default proposalService;