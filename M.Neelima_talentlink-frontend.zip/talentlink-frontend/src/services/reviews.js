import api from './api';

const reviewService = {
  // Get all reviews
  async getReviews(params = {}) {
    const response = await api.get('/reviews/', { params });
    return response.data;
  },

  // Get single review
  async getReview(id) {
    const response = await api.get(`/reviews/${id}/`);
    return response.data;
  },

  // Submit a review
  async submitReview(reviewData) {
    console.log('Submitting review:', reviewData);
    const response = await api.post('/reviews/', reviewData);
    return response.data;
  },

  // Get user statistics
  async getUserStats(userId) {
    const response = await api.get('/reviews/user_stats/', {
      params: { user_id: userId }
    });
    return response.data;
  },

  // Check if can review a contract
  async canReview(contractId) {
    try {
      const response = await api.get(`/contracts/${contractId}/`);
      const contract = response.data;
      
      // Can only review completed contracts
      return contract.status === 'COMPLETED' || contract.status === 'Completed';
    } catch (error) {
      console.error('Error checking review eligibility:', error);
      return false;
    }
  }
};

export default reviewService;