import api from './api';

const authService = {
  async login(email, password) {
    const response = await api.post('/auth/login/', { email, password });
    
    if (response.data.access) {
      localStorage.setItem('access_token', response.data.access);
      localStorage.setItem('refresh_token', response.data.refresh);
      localStorage.setItem('user', JSON.stringify(response.data.user));
    }
    
    return response.data;
  },
  
  async register(userData) {
    const response = await api.post('/auth/register/', userData);
    return response.data;
  },
  
  logout() {
    localStorage.removeItem('access_token');
    localStorage.removeItem('refresh_token');
    localStorage.removeItem('user');
  },
  
  getCurrentUser() {
    const userStr = localStorage.getItem('user');
    return userStr ? JSON.parse(userStr) : null;
  },
  
  async getProfile() {
    try {
      const response = await api.get('/auth/profile/');
      console.log('Get profile response:', response.data);
      // The response has user and profile nested
      return response.data;
    } catch (error) {
      console.error('Error fetching profile:', error);
      throw error;
    }
  },
  
  async updateProfile(profileData) {
    console.log('=== Profile Update Debug ===');
    console.log('1. Original profile data:', profileData);
    
    try {
      const response = await api.put('/auth/profile/', profileData);
      console.log('2. Server response:', response.data);
      
      // Update local storage with new user data if provided
      if (response.data.user) {
        localStorage.setItem('user', JSON.stringify(response.data.user));
      }
      
      return response.data;
    } catch (error) {
      console.error('3. Error details:', error.response?.data || error);
      throw error;
    }
  }
};

export default authService;