import api from './api';

const projectService = {
  // Get all projects with filters
  async getProjects(params = {}) {
    const response = await api.get('/projects/', { params });
    return response.data;
  },

  // Get single project
  async getProject(id) {
    const response = await api.get(`/projects/${id}/`);
    return response.data;
  },

  // Create new project (Client only)
  async createProject(projectData) {
    console.log('Creating project with data:', projectData);
    console.log('Required skills:', projectData.required_skills);
    console.log('Skills type:', typeof projectData.required_skills, Array.isArray(projectData.required_skills));
    
    // Ensure required_skills is an array
    if (projectData.required_skills && !Array.isArray(projectData.required_skills)) {
      console.log('Converting required_skills to array');
      try {
        projectData.required_skills = JSON.parse(projectData.required_skills);
      } catch (e) {
        console.error('Failed to parse required_skills:', e);
        projectData.required_skills = [];
      }
    }
    
    console.log('Final project data being sent:', JSON.stringify(projectData, null, 2));
    
    const response = await api.post('/projects/', projectData);
    console.log('Project creation response:', response.data);
    
    return response.data;
  },

  // Update project (Client only)
  async updateProject(id, projectData) {
    const response = await api.patch(`/projects/${id}/`, projectData);
    return response.data;
  },

  // Delete project (Client only)
  async deleteProject(id) {
    const response = await api.delete(`/projects/${id}/`);
    return response.data;
  },

  // Get my projects (Client only)
  async getMyProjects() {
    const response = await api.get('/projects/my_projects/');
    return response.data;
  }
};

export default projectService;