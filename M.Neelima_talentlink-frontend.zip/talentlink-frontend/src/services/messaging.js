import api from './api';

const messagingService = {
  // Get all conversations
  async getConversations() {
    console.log('Fetching conversations...');
    const response = await api.get('/messages/conversations/');
    console.log('Conversations response:', response.data);
    return response.data;
  },

  // Get conversation by contract ID
  async getConversationByContract(contractId) {
    console.log('Getting/Creating conversation for contract:', contractId);
    const response = await api.get('/messages/conversations/by_contract/', {
      params: { contract_id: contractId }
    });
    console.log('Conversation by contract response:', response.data);
    return response.data;
  },

  // Get messages for a conversation
  async getMessages(conversationId) {
    console.log('Fetching messages for conversation:', conversationId);
    const response = await api.get('/messages/', {
      params: { conversation_id: conversationId }
    });
    console.log('Messages response:', response.data);
    return response.data;
  },

  // Send a message
  async sendMessage(messageData) {
    console.log('Sending message:', messageData);
    const response = await api.post('/messages/', messageData);
    console.log('Send message response:', response.data);
    return response.data;
  },

  // Mark messages as read
  async markMessagesAsRead(conversationId) {
    const response = await api.post('/messages/mark_as_read/', {
      conversation_id: conversationId
    });
    return response.data;
  }
};

export default messagingService;