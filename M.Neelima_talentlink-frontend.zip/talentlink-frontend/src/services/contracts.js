import api from './api';

const contractService = {
  // Get all contracts (filtered by user type)
  async getContracts(params = {}) {
    const response = await api.get('/contracts/', { params });
    return response.data;
  },

  // Get single contract
  async getContract(id) {
    const response = await api.get(`/contracts/${id}/`);
    return response.data;
  },

  // Complete contract (Client only)
  async completeContract(id) {
    const response = await api.post(`/contracts/${id}/complete/`);
    return response.data;
  },

  // Terminate contract
  async terminateContract(id) {
    const response = await api.post(`/contracts/${id}/terminate/`);
    return response.data;
  },

  // Get contract analytics
  async getContractAnalytics(id) {
    const response = await api.get(`/contracts/${id}/analytics/`);
    return response.data;
  }
};

export default contractService;