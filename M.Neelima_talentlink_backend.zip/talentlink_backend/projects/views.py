from rest_framework import viewsets, permissions, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend
from django.db.models import Q

from .models import Project
from .serializers import ProjectSerializer, ProjectDetailSerializer
from .permissions import IsClientOwner

class ProjectViewSet(viewsets.ModelViewSet):
    queryset = Project.objects.all()
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['title', 'description']
    ordering_fields = ['created_at', 'budget_amount', 'duration_in_days']
    filterset_fields = ['status', 'budget_type']
    
    def get_serializer_class(self):
        if self.action == 'retrieve':
            return ProjectDetailSerializer
        return ProjectSerializer
    
    def get_permissions(self):
        if self.action in ['create', 'update', 'partial_update', 'destroy']:
            return [permissions.IsAuthenticated(), IsClientOwner()]
        return [permissions.AllowAny()]
    
    def get_queryset(self):
        queryset = Project.objects.select_related('client').all()
        
        # Filter by skills
        skills = self.request.query_params.get('skills', '')
        if skills:
            skills_list = [s.strip() for s in skills.split(',')]
            skill_query = Q()
            for skill in skills_list:
                skill_query |= Q(required_skills__contains=skill)
            queryset = queryset.filter(skill_query)
        
        # Filter by budget range
        min_budget = self.request.query_params.get('min_budget', None)
        max_budget = self.request.query_params.get('max_budget', None)
        if min_budget:
            queryset = queryset.filter(budget_amount__gte=min_budget)
        if max_budget:
            queryset = queryset.filter(budget_amount__lte=max_budget)
        
        return queryset
    
    def perform_create(self, serializer):
        serializer.save(client=self.request.user)
    
    @action(detail=False, methods=['get'], permission_classes=[permissions.IsAuthenticated])
    def my_projects(self, request):
        """Get projects created by the current client"""
        if request.user.user_type != 'CLIENT':
            return Response({'error': 'Only clients can access this endpoint'}, status=403)
        
        projects = self.queryset.filter(client=request.user)
        serializer = self.get_serializer(projects, many=True)
        return Response(serializer.data)