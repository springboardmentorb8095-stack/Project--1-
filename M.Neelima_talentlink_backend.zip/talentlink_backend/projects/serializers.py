from rest_framework import serializers
from .models import Project
from accounts.serializers import UserSerializer

class ProjectSerializer(serializers.ModelSerializer):
    client = UserSerializer(read_only=True)
    proposals_count = serializers.SerializerMethodField()
    required_skills = serializers.ListField(
        child=serializers.CharField(max_length=100),
        allow_empty=False
    )
    
    class Meta:
        model = Project
        fields = '__all__'
        read_only_fields = ('client', 'created_at', 'updated_at')
    
    def get_proposals_count(self, obj):
        return obj.proposals.count()


class ProjectDetailSerializer(ProjectSerializer):
    can_submit_proposal = serializers.SerializerMethodField()
    
    def get_can_submit_proposal(self, obj):
        request = self.context.get('request')
        if not request or not request.user.is_authenticated:
            return False
        
        if request.user.user_type != 'FREELANCER':
            return False
        
        # Check if freelancer already submitted a proposal
        return not obj.proposals.filter(freelancer=request.user).exists()