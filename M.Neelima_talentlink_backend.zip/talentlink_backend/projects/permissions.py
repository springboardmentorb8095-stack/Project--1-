from rest_framework import permissions

class IsClientOwner(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.user.user_type == 'CLIENT'
    
    def has_object_permission(self, request, view, obj):
        return obj.client == request.user