from django.contrib import admin
from .models import Contract

@admin.register(Contract)
class ContractAdmin(admin.ModelAdmin):
    list_display = ('proposal', 'client', 'freelancer', 'status', 'start_date', 'end_date')
    list_filter = ('status', 'start_date', 'end_date')
    search_fields = ('proposal__project__title', 'client__email', 'freelancer__email')
    raw_id_fields = ('proposal', 'client', 'freelancer', 'project')
    readonly_fields = ('created_at', 'updated_at', 'completed_at')