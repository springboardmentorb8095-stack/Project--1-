from rest_framework import serializers
from .models import Contract
from proposals.serializers import ProposalDetailSerializer
from accounts.serializers import UserSerializer
from projects.serializers import ProjectSerializer

class ContractSerializer(serializers.ModelSerializer):
    client = UserSerializer(read_only=True)
    freelancer = UserSerializer(read_only=True)
    project = ProjectSerializer(read_only=True)
    
    class Meta:
        model = Contract
        fields = '__all__'
        read_only_fields = ('created_at', 'updated_at', 'completed_at')


class ContractDetailSerializer(ContractSerializer):
    proposal = ProposalDetailSerializer(read_only=True)
    can_complete = serializers.SerializerMethodField()
    can_message = serializers.SerializerMethodField()
    
    def get_can_complete(self, obj):
        request = self.context.get('request')
        return obj.status == 'ACTIVE' and request.user == obj.client
    
    def get_can_message(self, obj):
        request = self.context.get('request')
        return request.user in [obj.client, obj.freelancer] and obj.status == 'ACTIVE'