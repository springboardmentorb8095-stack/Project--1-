from rest_framework import viewsets, permissions, status
from rest_framework.decorators import action
from rest_framework.response import Response
from django.utils import timezone

from .models import Contract
from .serializers import ContractSerializer, ContractDetailSerializer
from .permissions import IsContractParticipant
from reviews.models import Review

import logging

# Define logger at the top of the file
logger = logging.getLogger(__name__)

class ContractViewSet(viewsets.ModelViewSet):
    queryset = Contract.objects.all()
    permission_classes = [permissions.IsAuthenticated, IsContractParticipant]
    
    def get_serializer_class(self):
        if self.action == 'retrieve':
            return ContractDetailSerializer
        return ContractSerializer
    
    def get_queryset(self):
        user = self.request.user
        
        if user.user_type == 'CLIENT':
            return self.queryset.filter(client=user)
        elif user.user_type == 'FREELANCER':
            return self.queryset.filter(freelancer=user)
        
        return Contract.objects.none()
    
    @action(detail=True, methods=['post'], permission_classes=[permissions.IsAuthenticated])
    def complete(self, request, pk=None):
        """Mark contract as completed"""
        contract = self.get_object()
        
        if request.user != contract.client:
            return Response(
                {'error': 'Only the client can mark a contract as completed'}, 
                status=status.HTTP_403_FORBIDDEN
            )
        
        if contract.status != 'ACTIVE':
            return Response(
                {'error': 'Contract is not active'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        contract.status = 'COMPLETED'
        contract.completed_at = timezone.now()
        contract.save()
        
        # Update project status if all contracts are completed
        if not contract.project.contracts.filter(status='ACTIVE').exists():
            contract.project.status = 'COMPLETED'
            contract.project.save()
        
        return Response({'message': 'Contract marked as completed'})
    
    @action(detail=True, methods=['post'], permission_classes=[permissions.IsAuthenticated])
    def terminate(self, request, pk=None):
        """Terminate contract"""
        contract = self.get_object()
        
        if contract.status != 'ACTIVE':
            return Response(
                {'error': 'Only active contracts can be terminated'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        contract.status = 'TERMINATED'
        contract.save()
        
        return Response({'message': 'Contract terminated'})
    
    @action(detail=True, methods=['get'])
    def analytics(self, request, pk=None):
        """Get contract analytics"""
        contract = self.get_object()
        logger.info(f"Getting analytics for contract {pk}")
        
        try:
            # Calculate progress - handle both datetime and date objects
            if hasattr(contract.start_date, 'date'):
                start_date = contract.start_date.date()
            else:
                start_date = contract.start_date
                
            if hasattr(contract.end_date, 'date'):
                end_date = contract.end_date.date()
            else:
                end_date = contract.end_date
            
            today = timezone.now().date()
            
            print(start_date,end_date)
            # Calculate days
            total_days = (end_date - start_date).days
            elapsed_days = (today - start_date).days
            remaining_days = (end_date - today).days
            
            # Ensure elapsed days doesn't go negative
            elapsed_days = max(0, elapsed_days)
            
            # Calculate progress percentage
            if total_days > 0:
                progress_percentage = min((elapsed_days / total_days) * 100, 100)
            else:
                progress_percentage = 0
            
            # Get message count (handle if conversation doesn't exist)
            message_count = 0
            try:
                if hasattr(contract, 'conversation') and contract.conversation:
                    message_count = contract.conversation.messages.count()
            except Exception as e:
                logger.warning(f"Could not get message count: {e}")
            
            analytics_data = {
                'total_days': total_days,
                'elapsed_days': elapsed_days,
                'remaining_days': max(remaining_days, 0),
                'progress_percentage': round(progress_percentage, 2),
                'message_count': message_count,
                'total_amount': str(contract.total_amount),
                'status': contract.status
            }
            
            logger.info(f"Analytics data: {analytics_data}")
            return Response(analytics_data)
            
        except Exception as e:
            return Response(
                {'error': f'Failed to calculate analytics: {str(e)}'}, 
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )