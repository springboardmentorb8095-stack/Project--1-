from django.utils import timezone
from django.utils.deprecation import MiddlewareMixin

class LastActivityMiddleware(MiddlewareMixin):
    def process_request(self, request):
        if request.user.is_authenticated:
            # Update last activity timestamp
            request.user.last_activity = timezone.now()
            request.user.save(update_fields=['last_activity'])
        return None


class RequestLoggingMiddleware(MiddlewareMixin):
    def process_request(self, request):
        # Log API requests for monitoring
        if request.path.startswith('/api/'):
            print(f"[{timezone.now()}] {request.method} {request.path} - User: {request.user}")
        return None