from django.core.mail import send_mail
from django.conf import settings
from django.template.loader import render_to_string

def send_notification_email(user, subject, template_name, context):
    """Send notification emails"""
    message = render_to_string(template_name, context)
    send_mail(
        subject,
        message,
        settings.DEFAULT_FROM_EMAIL,
        [user.email],
        fail_silently=False,
    )

def calculate_proposal_score(proposal):
    """Calculate a score for proposal ranking"""
    score = 0
    
    # Skills match
    project_skills = set(proposal.project.required_skills)
    freelancer_skills = set(proposal.freelancer.freelancer_profile.skills)
    skill_match = len(project_skills.intersection(freelancer_skills)) / len(project_skills)
    score += skill_match * 40
    
    # Price competitiveness
    if proposal.proposed_rate <= proposal.project.budget_amount:
        price_ratio = proposal.proposed_rate / proposal.project.budget_amount
        score += (1 - price_ratio) * 30
    
    # Freelancer rating
    avg_rating = proposal.freelancer.reviews_received.aggregate(Avg('rating'))['rating__avg'] or 0
    score += (avg_rating / 5) * 20
    
    # Experience
    years_exp = proposal.freelancer.freelancer_profile.years_of_experience
    score += min(years_exp / 10, 1) * 10
    
    return round(score, 2)