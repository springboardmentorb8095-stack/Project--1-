# proposals/serializers.py
from rest_framework import serializers
from .models import Proposal
from accounts.serializers import UserSerializer
from projects.serializers import ProjectSerializer
from projects.models import Project
class ProposalSerializer(serializers.ModelSerializer):
    freelancer = UserSerializer(read_only=True)
    project = serializers.PrimaryKeyRelatedField(
        queryset=Project.objects.all(),
        write_only=True
    )
    project_details = ProjectSerializer(source='project', read_only=True)
    
    class Meta:
        model = Proposal
        fields = [
            'id', 'project', 'freelancer', 'cover_letter',
            'proposed_rate', 'estimated_duration', 'status',
            'created_at', 'updated_at','project_details'
        ]

class ProposalDetailSerializer(serializers.ModelSerializer):
    freelancer = UserSerializer(read_only=True)
    project = ProjectSerializer(read_only=True)
    
    class Meta:
        model = Proposal
        fields = '__all__'


class ProposalDetailSerializer(ProposalSerializer):
    project = ProjectSerializer(read_only=True)
    freelancer_profile = serializers.SerializerMethodField()

    class Meta:
        model = Proposal
        fields = [
            'id', 'project', 'freelancer', 'freelancer_profile',
            'cover_letter', 'proposed_rate', 'estimated_duration', 
            'status', 'created_at', 'updated_at'
        ]

    def get_freelancer_profile(self, obj):
        if hasattr(obj.freelancer, 'freelancer_profile'):
            from accounts.serializers import FreelancerProfileSerializer
            return FreelancerProfileSerializer(obj.freelancer.freelancer_profile).data
        return None
    
