from rest_framework import viewsets, permissions, status
from rest_framework.decorators import action
from rest_framework.response import Response
from django.shortcuts import get_object_or_404

from .models import Proposal
from .serializers import ProposalSerializer, ProposalDetailSerializer
from .permissions import IsProposalOwner
from contracts.models import Contract
from projects.models import Project

class ProposalViewSet(viewsets.ModelViewSet):
    queryset = Proposal.objects.all()
    
    def get_serializer_class(self):
        if self.action == 'retrieve':
            return ProposalDetailSerializer
        return ProposalSerializer
    
    def get_permissions(self):
        if self.action in ['create']:
            return [permissions.IsAuthenticated()]
        elif self.action in ['update', 'partial_update', 'destroy']:
            return [permissions.IsAuthenticated(), IsProposalOwner()]
        return [permissions.IsAuthenticated()]
    
    def get_queryset(self):
        user = self.request.user
        
        # Freelancers see their own proposals
        if user.user_type == 'FREELANCER':
            return self.queryset.filter(freelancer=user)
        
        # Clients see proposals for their projects
        elif user.user_type == 'CLIENT':
            return self.queryset.filter(project__client=user)
        
        return Proposal.objects.none()
    
    def perform_create(self, serializer):
        if self.request.user.user_type != 'FREELANCER':
            raise permissions.PermissionDenied('Only freelancers can submit proposals')
        
        project = get_object_or_404(Project, id=self.request.data.get('project'))
        
        # Check if project is open
        if project.status != 'OPEN':
            raise permissions.PermissionDenied('Project is not open for proposals')
        
        serializer.save(freelancer=self.request.user)
    
    @action(detail=True, methods=['post'], permission_classes=[permissions.IsAuthenticated])
    def accept(self, request, pk=None):
        """Client accepts a proposal"""
        proposal = self.get_object()
        
        if request.user.user_type != 'CLIENT' or proposal.project.client != request.user:
            return Response(
                {'error': 'Only the project client can accept proposals'}, 
                status=status.HTTP_403_FORBIDDEN
            )
        
        if proposal.status != 'PENDING':
            return Response(
                {'error': 'Proposal is not in pending status'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Update proposal status
        proposal.status = 'ACCEPTED'
        proposal.save()
        
        # Update project status
        proposal.project.status = 'IN_PROGRESS'
        proposal.project.save()
        
        # Create contract
        contract = Contract.objects.create(
            proposal=proposal,
            client=proposal.project.client,
            freelancer=proposal.freelancer,
            project=proposal.project,
            start_date=request.data.get('start_date'),
            end_date=request.data.get('end_date'),
            total_amount=proposal.proposed_rate * proposal.estimated_duration,
            terms=request.data.get('terms', 'Standard terms apply')
        )
        
        # Reject other pending proposals
        Proposal.objects.filter(
            project=proposal.project,
            status='PENDING'
        ).exclude(id=proposal.id).update(status='REJECTED')
        
        return Response({
            'message': 'Proposal accepted successfully',
            'contract_id': contract.id
        })
    
    @action(detail=True, methods=['post'], permission_classes=[permissions.IsAuthenticated])
    def reject(self, request, pk=None):
        """Client rejects a proposal"""
        proposal = self.get_object()
        
        if request.user.user_type != 'CLIENT' or proposal.project.client != request.user:
            return Response(
                {'error': 'Only the project client can reject proposals'}, 
                status=status.HTTP_403_FORBIDDEN
            )
        
        proposal.status = 'REJECTED'
        proposal.save()
        
        return Response({'message': 'Proposal rejected successfully'})