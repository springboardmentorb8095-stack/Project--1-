from rest_framework import serializers
from .models import Review
from accounts.serializers import UserSerializer
from contracts.serializers import ContractSerializer

class ReviewSerializer(serializers.ModelSerializer):
    reviewer = UserSerializer(read_only=True)
    reviewee = UserSerializer(read_only=True)
    
    class Meta:
        model = Review
        fields = '__all__'
        read_only_fields = ('reviewer', 'reviewee', 'contract', 'created_at', 'updated_at')


class ReviewDetailSerializer(ReviewSerializer):
    contract = ContractSerializer(read_only=True)