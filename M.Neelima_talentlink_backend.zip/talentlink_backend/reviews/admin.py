from django.contrib import admin
from .models import Review

@admin.register(Review)
class ReviewAdmin(admin.ModelAdmin):
    list_display = ('contract', 'reviewer', 'reviewee', 'rating', 'created_at')
    list_filter = ('rating', 'created_at')
    search_fields = ('comment', 'reviewer__email', 'reviewee__email')
    raw_id_fields = ('contract', 'reviewer', 'reviewee')
    readonly_fields = ('created_at', 'updated_at')