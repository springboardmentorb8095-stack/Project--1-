from rest_framework import viewsets, permissions, status
from rest_framework.decorators import action
from rest_framework.response import Response
from django.db.models import Avg
from django.shortcuts import get_object_or_404

from .models import Review
from .serializers import ReviewSerializer, ReviewDetailSerializer
from contracts.models import Contract
from accounts.models import User

class ReviewViewSet(viewsets.ModelViewSet):
    queryset = Review.objects.all()
    permission_classes = [permissions.IsAuthenticated]
    
    def get_serializer_class(self):
        if self.action == 'retrieve':
            return ReviewDetailSerializer
        return ReviewSerializer
    
    def get_queryset(self):
        user = self.request.user
        
        # Filter by user type
        if self.request.query_params.get('received'):
            return self.queryset.filter(reviewee=user)
        elif self.request.query_params.get('given'):
            return self.queryset.filter(reviewer=user)
        
        # Default: show all reviews where user is involved
        return self.queryset.filter(reviewer=user) | self.queryset.filter(reviewee=user)
    
    def perform_create(self, serializer):
        contract_id = self.request.data.get('contract_id')
        contract = get_object_or_404(Contract, id=contract_id)
        
        # Verify contract is completed
        if contract.status != 'COMPLETED':
            raise permissions.PermissionDenied('Can only review completed contracts')
        
        # Verify user is part of the contract
        if self.request.user not in [contract.client, contract.freelancer]:
            raise permissions.PermissionDenied('You are not part of this contract')
        
        # Determine reviewee
        reviewee = contract.freelancer if self.request.user == contract.client else contract.client
        
        # Check if review already exists
        if Review.objects.filter(
            contract=contract,
            reviewer=self.request.user,
            reviewee=reviewee
        ).exists():
            raise permissions.PermissionDenied('You have already reviewed this contract')
        
        serializer.save(
            contract=contract,
            reviewer=self.request.user,
            reviewee=reviewee
        )
    
    @action(detail=False, methods=['get'])
    def user_stats(self, request):
        """Get review statistics for a user"""
        user_id = request.query_params.get('user_id', request.user.id)
        user = get_object_or_404(User, id=user_id)
        
        reviews = Review.objects.filter(reviewee=user)
        
        stats = {
            'total_reviews': reviews.count(),
            'average_rating': reviews.aggregate(Avg('rating'))['rating__avg'] or 0,
            'rating_breakdown': {
                5: reviews.filter(rating=5).count(),
                4: reviews.filter(rating=4).count(),
                3: reviews.filter(rating=3).count(),
                2: reviews.filter(rating=2).count(),
                1: reviews.filter(rating=1).count(),
            }
        }
        
        return Response(stats)