from rest_framework import viewsets, permissions, status
from rest_framework.decorators import action
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from django.utils import timezone

from .models import Conversation, Message
from .serializers import ConversationSerializer, MessageSerializer
from contracts.models import Contract

class ConversationViewSet(viewsets.ModelViewSet):
    queryset = Conversation.objects.all()
    serializer_class = ConversationSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        user = self.request.user
        return self.queryset.filter(
            contract__in=Contract.objects.filter(
                client=user
            ) | Contract.objects.filter(
                freelancer=user
            )
        ).order_by('-updated_at')
    
    @action(detail=False, methods=['get', 'post'])  # Add POST method
    def by_contract(self, request):
        """Get or create conversation by contract ID"""
        contract_id = request.query_params.get('contract_id')
        if not contract_id:
            return Response(
                {'error': 'contract_id parameter is required'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        contract = get_object_or_404(Contract, id=contract_id)
        
        # Check permissions
        if request.user not in [contract.client, contract.freelancer]:
            return Response(
                {'error': 'You are not part of this contract'}, 
                status=status.HTTP_403_FORBIDDEN
            )
        
        # Check if contract is active
        if contract.status not in ['ACTIVE', 'Active']:
            return Response(
                {'error': 'Can only message on active contracts'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        conversation, created = Conversation.objects.get_or_create(contract=contract)
        
        # If newly created, add a system message
        if created:
            Message.objects.create(
                conversation=conversation,
                sender=request.user,
                content=f"Conversation started for contract: {contract.project.title}",
                is_read=False
            )
            conversation.updated_at = timezone.now()
            conversation.save()
        
        serializer = self.get_serializer(conversation, context={'request': request})
        return Response(serializer.data)


class MessageViewSet(viewsets.ModelViewSet):
    queryset = Message.objects.all()
    serializer_class = MessageSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        conversation_id = self.request.query_params.get('conversation_id')
        if conversation_id:
            return self.queryset.filter(conversation_id=conversation_id).order_by('created_at')
        return Message.objects.none()
    
    def perform_create(self, serializer):
        conversation = serializer.validated_data['conversation']
        
        # Verify user is part of the contract
        contract = conversation.contract
        if self.request.user not in [contract.client, contract.freelancer]:
            raise permissions.PermissionDenied('You cannot send messages in this conversation')
        
        # Save the message
        message = serializer.save(sender=self.request.user)
        
        # Update conversation's updated_at
        conversation.updated_at = timezone.now()
        conversation.save()
    
    @action(detail=False, methods=['post'])
    def mark_as_read(self, request):
        """Mark messages as read"""
        conversation_id = request.data.get('conversation_id')
        if not conversation_id:
            return Response(
                {'error': 'conversation_id is required'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Update unread messages
        updated = Message.objects.filter(
            conversation_id=conversation_id,
            is_read=False
        ).exclude(sender=request.user).update(is_read=True)
        
        return Response({'messages_marked': updated})