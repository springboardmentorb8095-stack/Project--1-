from rest_framework import serializers
from .models import Conversation, Message
from accounts.serializers import UserSerializer
from contracts.serializers import ContractSerializer

class MessageSerializer(serializers.ModelSerializer):
    sender = UserSerializer(read_only=True)
    
    class Meta:
        model = Message
        fields = '__all__'
        read_only_fields = ('sender', 'created_at')


class ConversationSerializer(serializers.ModelSerializer):
    messages = MessageSerializer(many=True, read_only=True)
    last_message = serializers.SerializerMethodField()
    unread_count = serializers.SerializerMethodField()
    other_user = serializers.SerializerMethodField()
    contract = ContractSerializer(read_only=True)
    
    class Meta:
        model = Conversation
        fields = ['id', 'contract', 'messages', 'last_message', 'unread_count', 'other_user', 'created_at', 'updated_at']
        read_only_fields = ('created_at', 'updated_at')
    
    def get_last_message(self, obj):
        last_message = obj.messages.order_by('-created_at').first()
        if last_message:
            return MessageSerializer(last_message).data
        return None
    
    def get_unread_count(self, obj):
        request = self.context.get('request')
        if request and request.user:
            return obj.messages.filter(is_read=False).exclude(sender=request.user).count()
        return 0
    
    def get_other_user(self, obj):
        request = self.context.get('request')
        if request and request.user:
            if obj.contract.client == request.user:
                return UserSerializer(obj.contract.freelancer).data
            else:
                return UserSerializer(obj.contract.client).data
        return None