from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from accounts.models import FreelancerProfile, ClientProfile
from projects.models import Project
from datetime import datetime, timedelta

User = get_user_model()

class Command(BaseCommand):
    help = 'Creates sample data for testing'
    
    def handle(self, *args, **kwargs):
        # Create clients
        client1 = User.objects.create_user(
            username='techcorp',
            email='client@techcorp.com',
            password='testpass123',
            user_type='CLIENT',
            first_name='Tech',
            last_name='Corp'
        )
        
        ClientProfile.objects.create(
            user=client1,
            company_name='Tech Corp',
            company_description='Leading technology company',
            industry='Technology',
            company_size='100-500',
            location='San Francisco, CA'
        )
        
        # Create freelancers
        freelancer1 = User.objects.create_user(
            username='johndev',
            email='john@freelancer.com',
            password='testpass123',
            user_type='FREELANCER',
            first_name='John',
            last_name='Developer'
        )
        
        FreelancerProfile.objects.create(
            user=freelancer1,
            title='Full Stack Developer',
            bio='Experienced developer with 5+ years in web development',
            skills=['Python', 'Django', 'React', 'PostgreSQL'],
            hourly_rate=75.00,
            years_of_experience=5
        )
        
        # Create sample projects
        Project.objects.create(
            client=client1,
            title='E-commerce Platform Development',
            description='Need a full-stack developer to build an e-commerce platform',
            required_skills=['Django', 'React', 'PostgreSQL'],
                        budget_type='FIXED',
            budget_amount=10000,
            duration_in_days=60,
            deadline=datetime.now() + timedelta(days=60)
        )
        
        Project.objects.create(
            client=client1,
            title='Mobile App Backend API',
            description='Develop RESTful API for mobile application',
            required_skills=['Django', 'DRF', 'PostgreSQL', 'Redis'],
            budget_type='HOURLY',
            budget_amount=80,
            duration_in_days=30,
            deadline=datetime.now() + timedelta(days=30)
        )
        
        self.stdout.write(self.style.SUCCESS('Sample data created successfully'))