from rest_framework import serializers
from django.contrib.auth import get_user_model
from django.contrib.auth.password_validation import validate_password
from .models import FreelancerProfile, ClientProfile

User = get_user_model()

class UserRegistrationSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, required=True, validators=[validate_password])
    password2 = serializers.CharField(write_only=True, required=True)
    
    class Meta:
        model = User
        fields = ('username', 'email', 'password', 'password2', 'user_type', 'first_name', 'last_name')
    
    def validate(self, attrs):
        if attrs['password'] != attrs['password2']:
            raise serializers.ValidationError({"password": "Password fields didn't match."})
        return attrs
    
    def create(self, validated_data):
        validated_data.pop('password2')
        user = User.objects.create_user(**validated_data)
        
        # Create profile based on user type
        if user.user_type == 'FREELANCER':
            FreelancerProfile.objects.create(
                user=user,
                title="",
                bio="",
                hourly_rate=0
            )
        elif user.user_type == 'CLIENT':
            ClientProfile.objects.create(
                user=user,
                company_name="",
                company_description="",
                industry="",
                company_size="",
                location=""
            )
        
        return user


# In accounts/serializers.py
class UserSerializer(serializers.ModelSerializer):
    average_rating = serializers.SerializerMethodField()
    total_reviews = serializers.SerializerMethodField()
    
    class Meta:
        model = User
        fields = ('id', 'username', 'email', 'first_name', 'last_name', 
                 'user_type', 'is_email_verified', 'average_rating', 'total_reviews')
        read_only_fields = ('id', 'is_email_verified', 'average_rating', 'total_reviews')
    
    def get_average_rating(self, obj):
        from reviews.models import Review
        from django.db.models import Avg
        avg = Review.objects.filter(reviewee=obj).aggregate(Avg('rating'))['rating__avg']
        return round(avg, 1) if avg else 0.0
    
    def get_total_reviews(self, obj):
        from reviews.models import Review
        return Review.objects.filter(reviewee=obj).count()
    
    def get_full_name(self, obj):
        return f"{obj.first_name} {obj.last_name}".strip() or obj.email

class FreelancerProfileSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    skills = serializers.ListField(
        child=serializers.CharField(max_length=100),
        allow_empty=True,
        required=False,
        default=list
    )
    
    class Meta:
        model = FreelancerProfile
        fields = '__all__'
        read_only_fields = ('created_at', 'updated_at', 'user')
    
    def validate_skills(self, value):
        """Ensure skills is always a list"""
        if value is None:
            return []
        if isinstance(value, str):
            try:
                return json.loads(value)
            except:
                return []
        if isinstance(value, list):
            # Filter out empty strings
            return [skill for skill in value if skill and skill.strip()]
        return []
    
    def to_representation(self, instance):
        """Ensure skills is always returned as a list"""
        data = super().to_representation(instance)
        
        # Ensure skills is always a list
        if 'skills' in data:
            if data['skills'] is None:
                data['skills'] = []
            elif isinstance(data['skills'], str):
                try:
                    data['skills'] = json.loads(data['skills'])
                except:
                    data['skills'] = []
            elif not isinstance(data['skills'], list):
                data['skills'] = []
        
        return data

class ClientProfileSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    
    class Meta:
        model = ClientProfile
        fields = '__all__'
        read_only_fields = ('created_at', 'updated_at')


class LoginSerializer(serializers.Serializer):
    email = serializers.EmailField()
    password = serializers.CharField(write_only=True)