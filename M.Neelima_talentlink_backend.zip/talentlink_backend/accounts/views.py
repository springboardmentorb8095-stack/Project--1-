from rest_framework import status, generics, permissions
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth import authenticate
from django.shortcuts import get_object_or_404

import json
import logging

from .models import User, FreelancerProfile, ClientProfile
from .serializers import (
    UserRegistrationSerializer, 
    UserSerializer,
    FreelancerProfileSerializer, 
    ClientProfileSerializer,
    LoginSerializer
)

# Define logger at the top of the file
logger = logging.getLogger(__name__)


class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = UserRegistrationSerializer
    permission_classes = [permissions.AllowAny]


@api_view(['POST'])
@permission_classes([permissions.AllowAny])
def login_view(request):
    serializer = LoginSerializer(data=request.data)
    if serializer.is_valid():
        email = serializer.validated_data['email']
        password = serializer.validated_data['password']
        
        user = authenticate(email=email, password=password)
        
        if user:
            refresh = RefreshToken.for_user(user)
            
            # Get profile data based on user type
            profile_data = None
            if user.user_type == 'FREELANCER' and hasattr(user, 'freelancer_profile'):
                profile_data = FreelancerProfileSerializer(user.freelancer_profile).data
            elif user.user_type == 'CLIENT' and hasattr(user, 'client_profile'):
                profile_data = ClientProfileSerializer(user.client_profile).data
            
            return Response({
                'refresh': str(refresh),
                'access': str(refresh.access_token),
                'user': UserSerializer(user).data,
                'profile': profile_data
            })
        else:
            return Response(
                {'error': 'Invalid credentials'}, 
                status=status.HTTP_401_UNAUTHORIZED
            )
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class ProfileView(generics.RetrieveUpdateAPIView):
    permission_classes = [permissions.IsAuthenticated]
    
    def get_serializer_class(self):
        if self.request.user.user_type == 'FREELANCER':
            return FreelancerProfileSerializer
        return ClientProfileSerializer
    
    def get_object(self):
        if self.request.user.user_type == 'FREELANCER':
            profile, created = FreelancerProfile.objects.get_or_create(
                user=self.request.user,
                defaults={
                    'title': '',
                    'bio': '',
                    'hourly_rate': 0,
                    'skills': []  # Make sure this is a list
                }
            )
            # If profile was created before with null skills, fix it
            if profile.skills is None:
                profile.skills = []
                profile.save()
            return profile
        else:
            profile, created = ClientProfile.objects.get_or_create(
                user=self.request.user,
                defaults={
                    'company_name': '',
                    'company_description': '',
                    'industry': '',
                    'company_size': '',
                    'location': ''
                }
            )
            return profile
    
    def retrieve(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = self.get_serializer(instance)
        
        if request.user.user_type == 'FREELANCER':
            print(f"Skills: {instance.skills}")
        
        return Response({
            'user': UserSerializer(request.user).data,
            'profile': serializer.data
        })
    
    def update(self, request, *args, **kwargs):
        logger.info(f"Received data: {request.data}")

        partial = kwargs.pop('partial', True)
        instance = self.get_object()
        
        # Create mutable copy of request data
        mutable_data = request.data.copy() if hasattr(request.data, 'copy') else dict(request.data)
        
        # If freelancer, ensure skills is properly handled
        if request.user.user_type == 'FREELANCER' and 'skills' in mutable_data:
            skills_data = mutable_data['skills']
            print(f"Skills data received: {skills_data}, type: {type(skills_data)}")
            
            # Ensure skills is a list
            if isinstance(skills_data, str):
                try:
                    mutable_data['skills'] = json.loads(skills_data)
                except json.JSONDecodeError:
                    mutable_data['skills'] = []
            elif not isinstance(skills_data, list):
                mutable_data['skills'] = []
            
        
        serializer = self.get_serializer(instance, data=mutable_data, partial=partial)
        if serializer.is_valid():
            serializer.save()
            print(f"Profile saved successfully")
            
            return Response({
                'user': UserSerializer(request.user).data,
                'profile': serializer.data
            })
        else:
            print(f"Validation errors: {serializer.errors}")
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET'])
def freelancer_list(request):
    """Public endpoint to browse freelancers"""
    freelancers = FreelancerProfile.objects.select_related('user').all()
    
    # Filter by skills if provided
    skills = request.query_params.get('skills', '')
    if skills:
        skills_list = [s.strip() for s in skills.split(',')]
        for skill in skills_list:
            freelancers = freelancers.filter(skills__contains=skill)
    
    serializer = FreelancerProfileSerializer(freelancers, many=True)
    return Response(serializer.data)