from django.contrib import admin
from .models import User, FreelancerProfile, ClientProfile

@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ('username', 'email', 'user_type', 'is_email_verified', 'created_at')
    list_filter = ('user_type', 'is_email_verified')
    search_fields = ('username', 'email')

@admin.register(FreelancerProfile)
class FreelancerProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'title', 'hourly_rate', 'get_skills_display')
    search_fields = ('user__username', 'user__email', 'title')
    
    def get_skills_display(self, obj):
        if obj.skills:
            return ', '.join(obj.skills) if isinstance(obj.skills, list) else str(obj.skills)
        return 'No skills'
    get_skills_display.short_description = 'Skills'

@admin.register(ClientProfile)
class ClientProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'company_name', 'industry', 'company_size')
    search_fields = ('user__username', 'company_name', 'industry')