from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from django.db.models import Count, Sum, Avg, Q
from django.utils import timezone
from datetime import timedelta
import logging

from projects.models import Project
from proposals.models import Proposal
from contracts.models import Contract
from reviews.models import Review

logger = logging.getLogger(__name__)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def freelancer_dashboard(request):
    """Dashboard data for freelancers"""
    if request.user.user_type != 'FREELANCER':
        return Response({'error': 'Access denied'}, status=403)
    
    user = request.user
    
    # Debug logging
    logger.info(f"Fetching dashboard for freelancer: {user.email}")
    
    # Get statistics
    total_proposals = Proposal.objects.filter(freelancer=user).count()
    accepted_proposals = Proposal.objects.filter(
        freelancer=user, 
        status__iexact='ACCEPTED'  # Case-insensitive
    ).count()
    
    # Use case-insensitive comparison for status
    active_contracts = Contract.objects.filter(
        freelancer=user, 
        status__iexact='Active'  # Case-insensitive comparison
    ).count()
    
    completed_contracts = Contract.objects.filter(
        freelancer=user, 
        status__iexact='Completed'  # Case-insensitive comparison
    ).count()
    
    # Debug: Log all contracts for this freelancer
    all_contracts = Contract.objects.filter(freelancer=user)
    logger.info(f"Total contracts for {user.email}: {all_contracts.count()}")
    for contract in all_contracts:
        logger.info(f"Contract {contract.id} - Project: {contract.project.title} - Status: '{contract.status}'")
    
    # Debug: Check specific active contracts
    active_contracts_qs = Contract.objects.filter(freelancer=user, status__iexact='Active')
    logger.info(f"Active contracts query count: {active_contracts_qs.count()}")
    for contract in active_contracts_qs:
        logger.info(f"Active Contract: {contract.id} - {contract.project.title}")
    
    # Earnings
    total_earnings = Contract.objects.filter(
        freelancer=user, 
        status__iexact='Completed'
    ).aggregate(total=Sum('total_amount'))['total'] or 0
    
    # This month's earnings
    start_of_month = timezone.now().replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    monthly_earnings = Contract.objects.filter(
        freelancer=user,
        status__iexact='Completed',
        completed_at__gte=start_of_month
    ).aggregate(total=Sum('total_amount'))['total'] or 0
    
    # Average rating
    avg_rating = Review.objects.filter(reviewee=user).aggregate(
        avg=Avg('rating')
    )['avg'] or 0
    
    # Recent proposals
    recent_proposals = Proposal.objects.filter(
        freelancer=user
    ).select_related('project__client').order_by('-created_at')[:5]
    
    # Recent contracts - make sure to get Active ones too
    recent_contracts = Contract.objects.filter(
        freelancer=user
    ).select_related('project', 'client').order_by('-created_at')[:5]
    
    # Log recent contracts
    logger.info(f"Recent contracts count: {recent_contracts.count()}")
    for contract in recent_contracts:
        logger.info(f"Recent contract: {contract.id} - Status: {contract.status}")
    
    # Skills match - find matching projects
    matching_projects = 0
    if hasattr(user, 'freelancer_profile'):
        user_skills = user.freelancer_profile.skills or []
        if user_skills:  # Only if user has skills
            matching_projects = Project.objects.filter(
                status__iexact='Open',
                required_skills__overlap=user_skills
            ).exclude(
                proposals__freelancer=user
            ).count()
    
    from proposals.serializers import ProposalSerializer
    from contracts.serializers import ContractSerializer
    
    # Debug: Print final statistics
    logger.info(f"Final statistics for {user.email}:")
    logger.info(f"- Active contracts: {active_contracts}")
    logger.info(f"- Total proposals: {total_proposals}")
    logger.info(f"- Accepted proposals: {accepted_proposals}")
    logger.info(f"- Recent contracts data: {ContractSerializer(recent_contracts, many=True).data}")
    
    response_data = {
        'statistics': {
            'total_proposals': total_proposals,
            'accepted_proposals': accepted_proposals,
            'acceptance_rate': round((accepted_proposals / total_proposals * 100) if total_proposals > 0 else 0, 2),
            'active_contracts': active_contracts,
            'completed_contracts': completed_contracts,
            'total_earnings': str(total_earnings),
            'monthly_earnings': str(monthly_earnings),
            'average_rating': round(avg_rating, 2),
            'matching_projects': matching_projects,
        },
        'recent_proposals': ProposalSerializer(recent_proposals, many=True).data,
        'recent_contracts': ContractSerializer(recent_contracts, many=True).data,
    }
    
    return Response(response_data)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def client_dashboard(request):
    """Dashboard data for clients"""
    if request.user.user_type != 'CLIENT':
        return Response({'error': 'Access denied'}, status=403)
    
    user = request.user
    
    # Get statistics with case-insensitive status comparison
    total_projects = Project.objects.filter(client=user).count()
    open_projects = Project.objects.filter(
        client=user, 
        status__iexact='Open'
    ).count()
    in_progress_projects = Project.objects.filter(
        client=user, 
        status__iexact='In Progress'
    ).count()
    completed_projects = Project.objects.filter(
        client=user, 
        status__iexact='Completed'
    ).count()
    
    # Proposals statistics
    total_proposals_received = Proposal.objects.filter(project__client=user).count()
    pending_proposals = Proposal.objects.filter(
        project__client=user, 
        status__iexact='Pending'
    ).count()
    
    # Spending
    total_spent = Contract.objects.filter(
        client=user,
        status__iexact='Completed'
    ).aggregate(total=Sum('total_amount'))['total'] or 0
    
    # Active contracts value
    active_contracts_value = Contract.objects.filter(
        client=user,
        status__iexact='Active'
    ).aggregate(total=Sum('total_amount'))['total'] or 0
    
    # Recent projects
    recent_projects = Project.objects.filter(
        client=user
    ).order_by('-created_at')[:5]
    
    # Recent proposals
    recent_proposals = Proposal.objects.filter(
        project__client=user,
        status__iexact='Pending'
    ).select_related('freelancer', 'project').order_by('-created_at')[:5]
    
    # Average project duration
    completed_contracts = Contract.objects.filter(
        client=user,
        status__iexact='Completed',
        completed_at__isnull=False
    )
    
    if completed_contracts.exists():
        avg_duration = sum(
            (c.completed_at - c.start_date).days for c in completed_contracts
        ) / completed_contracts.count()
    else:
        avg_duration = 0
    
    from projects.serializers import ProjectSerializer
    from proposals.serializers import ProposalDetailSerializer
    
    return Response({
        'statistics': {
            'total_projects': total_projects,
            'open_projects': open_projects,
            'in_progress_projects': in_progress_projects,
            'completed_projects': completed_projects,
            'total_proposals_received': total_proposals_received,
            'pending_proposals': pending_proposals,
            'total_spent': str(total_spent),
            'active_contracts_value': str(active_contracts_value),
            'average_project_duration': round(avg_duration, 1),
        },
        'recent_projects': ProjectSerializer(recent_projects, many=True).data,
        'recent_proposals': ProposalDetailSerializer(recent_proposals, many=True).data,
    })