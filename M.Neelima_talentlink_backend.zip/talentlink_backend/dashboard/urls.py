from django.urls import path
from .views import freelancer_dashboard, client_dashboard

urlpatterns = [
    path('freelancer/', freelancer_dashboard, name='freelancer-dashboard'),
    path('client/', client_dashboard, name='client-dashboard'),
   # path('analytics/', analytics_view, name='analytics'),
]